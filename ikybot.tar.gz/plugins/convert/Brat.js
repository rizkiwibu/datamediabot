import axios from 'axios'

export const run = {
   usage: ['brat'],
   use: 'text [-animated]',
   category: 'converter',
   async: async (m, {
      client,
      text, 
      isPrefix,
      command,
      Utils
   }) => {
      try {
         // Mengambil exif dari global db untuk packname/author
         let exif = global.db.setting; 
         
         if (!text) return client.reply(m.chat, Utils.example(isPrefix, command, 'neoxr bot'), m);
         
         const MAX_CHAR = 30;
         const hasAnimatedFlag = /\s-animated\s*$/i.test(text);

         // Teks harus di-clean dulu untuk cek panjang
         const cleanText = text.replace(hasAnimatedFlag ? /\s-animated\s*$/i : /^\s*$/, '').trim();
         
         if (cleanText.length > MAX_CHAR && !hasAnimatedFlag) {
            return client.reply(m.chat, Utils.texted('bold', `🚩 Maksimal ${MAX_CHAR} karakter untuk stiker statis.`), m);
         }
         
         if (!cleanText) {
             return client.reply(m.chat, Utils.texted('bold', "Silakan berikan teks sebelum flag -animated."), m);
         }

         client.sendReact(m.chat, '🕒', m.key);

         // 1. Tentukan Endpoint API
         const baseUrl = "https://inusoft-brat.hf.space/api/";
         const endpoint = hasAnimatedFlag ? "bratvid" : "brat";
         
         // 2. Panggilan API Pertama (Dapatkan URL Media)
         const url = `${baseUrl}${endpoint}?text=${encodeURIComponent(cleanText)}`;

         const { data: jsonUrl } = await axios.get(url);

         if (!jsonUrl || !jsonUrl.URL) {
            client.sendReact(m.chat, '❌', m.key);
            return client.reply(m.chat, Utils.texted('bold', `🚩 Gagal membuat stiker brat.`), m);
         }

         // 3. Panggilan API Kedua (Dapatkan Buffer stiker)
         const stickerUrl = jsonUrl.URL.trim();
         
         const { data: buffer } = await axios.get(stickerUrl, {
            responseType: 'arraybuffer'
         });

         // 4. Mengirim Stiker menggunakan Buffer Langsung
         // Menggunakan Buffer.from(buffer) untuk memastikan tipe data benar, 
         // lalu mengirimnya ke client.sendSticker
         await client.sendSticker(m.chat, Buffer.from(buffer), m, {
            packname: exif.sk_pack,
            author: exif.sk_author
            // Catatan: Emojis tidak dimasukkan di sini, karena sudah diatur oleh API Brat
         });
         
         client.sendReact(m.chat, '✅', m.key);
         
      } catch (e) {
         console.error("Brat Sticker Error:", e);
         client.sendReact(m.chat, '❌', m.key);
         return client.reply(m.chat, Utils.jsonFormat(e), m); 
      }
   },
   error: false,
   limit: true
}
