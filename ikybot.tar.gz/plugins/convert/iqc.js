import axios from 'axios'

export const run = {

   usage: ['iqc'],

   use: 'text',

   category: 'converter',

   async: async (m, {

      client,

      text,

      isPrefix,

      command,

      setting: exif,

      Utils

   }) => {

      try {

         if (!text) return client.reply(m.chat, Utils.example(isPrefix, command, 'hello bro'), m)

         let old = new Date()

         client.sendReact(m.chat, '🕒', m.key)

         const { data } = await axios.get(`https://api.zenitsu.web.id/api/maker/iqc?text=${text}&apikey=znx`, { responseType: 'arraybuffer' })

         client.sendFile(m.chat, data, 'iqc.png', `🍟 *Process* : ${((new Date - old) * 1)} ms`, m)

      } catch (e) {

         return client.reply(m.chat, Utils.jsonFormat(e), m)

      }

   },

   error: false,

   limit: true

}