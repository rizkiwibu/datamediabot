import axios from "axios";

import { v4 as uuidv4 } from "uuid";

export const run = {

    usage: ["nanobanana"],

    use: "reply image + prompt",

    category: "ai",

    async: async (m, { client, text }) => {

        try {

            if (!text) return m.reply("Masukkan prompt.\nContoh: *nanobanana ubah rambut jadi pirang*");

            const q = m.quoted ? m.quoted : m;

            const mime = q.mimetype || "";

            if (!mime || !/image/.test(mime)) {

                return m.reply("Reply sebuah gambar!");

            }

            client.sendReact(m.chat, "🕒", m.key);

            const media = await q.download();

            const buffer = Buffer.isBuffer(media) ? media : Buffer.from(media);

            const resultURL = await nanobanana(text, buffer);

            if (!resultURL) return m.reply("Gagal mendapatkan hasil.");

            // Download hasil gambar → lalu kirim balik sebagai image

            const img = await axios.get(resultURL, { responseType: "arraybuffer" });

            await client.sendMessage(

                m.chat,

                {

                    image: Buffer.from(img.data),

                    caption: `✨ *Nano Banana Result*\nPrompt: ${text}`

                },

                { quoted: m }

            );

        } catch (err) {

            console.error("NANO BANANA ERROR:", err);

            return m.reply("Error: " + err.message);

        }

    },

    error: false,

    limit: false,

    premium: false

};

/* ============================================================

   FUNGSI SCRAPER NANO BANANA (DALAM 1 FILE)

   ============================================================ */

async function nanobanana(prompt, imageBuffer) {

    try {

        if (!prompt) throw new Error("Prompt is required.");

        if (!Buffer.isBuffer(imageBuffer)) throw new Error("Image must be buffer.");

        const identity = uuidv4();

        const inst = axios.create({

            baseURL: "https://supawork.ai/supawork/headshot/api",

            headers: {

                authorization: "null",

                origin: "https://supawork.ai/",

                referer: "https://supawork.ai/nano-banana",

                "user-agent":

                    "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36",

                "x-auth-challenge": "",

                "x-identity-id": identity,

            },

        });

        // 1. Token upload

        const { data: up } = await inst.get("/sys/oss/token", {

            params: { f_suffix: "png", get_num: 1, unsafe: 1 },

        });

        const img = up?.data?.[0];

        if (!img) throw new Error("Upload URL not found.");

        // 2. Upload gambar

        await axios.put(img.put, imageBuffer);

        // 3. Bypass CF

        const { data: cf } = await axios.post(

            "https://api.nekolabs.web.id/tools/bypass/cf-turnstile",

            {

                url: "https://supawork.ai/nano-banana",

                siteKey: "0x4AAAAAACBjrLhJyEE6mq1c",

            }

        );

        if (!cf?.result) throw new Error("Failed CF token.");

        const { data: ch } = await inst.get("/sys/challenge/token", {

            headers: { "x-auth-challenge": cf.result },

        });

        if (!ch?.data?.challenge_token)

            throw new Error("Failed challenge token.");

        const challengeToken = ch.data.challenge_token;

        // 4. Create task

        const { data: task } = await inst.post(

            "/media/image/generator",

            {

                identity_id: identity,

                aigc_app_code: "image_to_image_generator",

                aspect_ratio: "match_input_image",

                currency_type: "silver",

                custom_prompt: prompt,

                image_urls: [img.get],

                model_code: "google_nano_banana",

            },

            { headers: { "x-auth-challenge": challengeToken } }

        );

        if (!task?.data?.creation_id)

            throw new Error("Failed create task.");

        // 5. Polling

        while (true) {

            const { data } = await inst.get("/media/aigc/result/list/v1", {

                params: {

                    page_no: 1,

                    page_size: 10,

                    identity_id: identity,

                },

            });

            const result = data?.data?.list?.[0]?.list?.[0];

            if (result?.status === 1) {

                return result.url;

            }

            await new Promise((res) => setTimeout(res, 1000));

        }

    } catch (err) {

        throw new Error(err.message);

    }

}