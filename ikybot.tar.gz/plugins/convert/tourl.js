import uploader from "../../lib/uploader.js";

export const run = {

    usage: ["tourl", "upload"],

    use: "reply media",

    category: "tools",

    async: async (m, { client, Utils }) => {

        try {

            // Ambil media

            const q = m.quoted ? m.quoted : m;

            const mime = (q.msg || q).mimetype || "";

            if (!mime) {

                return m.reply("📸 Reply media yang ingin diupload.");

            }

            if (!/image|video|audio|document|webp|webm/.test(mime)) {

                return m.reply("❌ Format tidak didukung. Reply media yang valid!");

            }

            client.sendReact(m.chat, "🕒", m.key);

            const media = await q.download();

            const buffer = Buffer.isBuffer(media) ? media : Buffer.from(media);

            // Upload ke Catbox (auto)

            const url = await uploader.upload(buffer);

            return m.reply(`✔️ *Uploaded successfully!*\n\n${url}`);

        } catch (e) {

            console.error("UPLOAD ERROR:", e);

            return m.reply(Utils.jsonFormat(e));

        }

    },

    error: false,

    limit: false,

    premium: false

};