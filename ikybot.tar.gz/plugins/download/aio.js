import axios from "axios";

export const run = {

    usage: ["aio"],

    use: "url",

    category: "downloader",

    cooldown: 5,

    limit: true,

    premium: true, // <<<<< DITAMBAHKAN DI SINI

    async: async (m, { client, text, isPrefix, command, Utils }) => {

        try {

            // =====================================================

            // 1 — Jika user memilih kualitas/media (SINGLE_SELECT)

            // (TIDAK BERUBAH)

            // =====================================================

            if (text && text.startsWith("choose")) {

                const [_cmd, type, rawUrl, ...titleArray] = text.split(" ");

                const mediaUrl = decodeURIComponent(rawUrl);

                const title = decodeURIComponent(titleArray.join(" ")) || "AIO Media";

                client.sendReact(m.chat, "⬇️", m.key);

                const { data: buff } = await axios.get(mediaUrl, { responseType: "arraybuffer" });

                const buffer = Buffer.from(buff);

                if (type === "video") {

                    return client.sendMessage(m.chat, { video: buffer }, { quoted: m });

                }

                if (type === "audio") {

                    return client.sendMessage(

                        m.chat,

                        {

                            audio: buffer,

                            mimetype: "audio/mpeg",

                            fileName: `${title}.mp3`

                        },

                        { quoted: m }

                    );

                }

                if (type === "image") {

                    // Tipe image kemungkinan tidak tersedia di API Tioo

                    return client.reply(m.chat, "❌ Tipe media 'image' tidak didukung oleh API saat ini.", m);

                }

                return client.reply(m.chat, "❌ Tipe media tidak dikenal.", m);

            }

            // =====================================================

            // 2 — MODE DOWNLOAD UTAMA

            // (MENGGUNAKAN API TIOO DENGAN PENYESUAIAN FORMAT)

            // =====================================================

            if (!text)

                return client.reply(

                    m.chat,

                    Utils.example(isPrefix, command, "https://tiktok.com/xxxx"),

                    m

                );

            client.sendReact(m.chat, "⏳", m.key);

            // Ganti ke API Tioo

            const apiUrl = `https://backend1.tioo.eu.org/aio?url=${encodeURIComponent(text)}`;

            const { data: apiResponse } = await axios.get(apiUrl);

            

            // Pengecekan status

            if (apiResponse?.status !== "ok" || !apiResponse?.data)

                return client.reply(m.chat, `❌ AIO ERROR: ${apiResponse?.mess || 'Gagal memproses URL.'}`, m);

            

            // Data hasil utama (r) dari API Tioo

            const r = apiResponse.data;

            

            const videos = r.links?.video || [];

            const audios = r.links?.audio || [];

            // Memetakan hasil API Tioo ke format 'r.medias' yang diharapkan oleh kode List Select

            const listMedias = [];

            // Mapping Video

            videos.forEach(item => {

                listMedias.push({

                    type: "video",

                    quality: item.q_text,

                    extension: "mp4", // Asumsi

                    filesize: item.size,

                    url: item.url,

                });

            });

            // Mapping Audio

            audios.forEach(item => {

                listMedias.push({

                    type: "audio",

                    quality: item.q_text,

                    extension: "mp3", // Asumsi

                    filesize: item.size,

                    url: item.url,

                });

            });

            if (listMedias.length === 0)

                return client.reply(m.chat, "❌ Tidak ada media ditemukan.", m);

            // =====================================================

            // 3 — BIKIN LIST SINGLE_SELECT (Menggunakan listMedias)

            // =====================================================

            const rows = listMedias.map((item, i) => ({

                title: `${item.type.toUpperCase()} • ${item.quality || item.extension || ""}`,

                description: item.filesize || "",

                // URL media dan Title harus di-encode

                id: `${isPrefix}${command} choose ${item.type} ${encodeURIComponent(item.url)} ${encodeURIComponent(r.title || "AIO")}`

            }));

            const buttons = [

                {

                    name: "single_select",

                    buttonParamsJson: JSON.stringify({

                        title: "Pilih Media",

                        sections: [

                            {

                                title: "AIO Media List",

                                rows

                            }

                        ]

                    })

                }

            ];

            // =====================================================

            // 4 — KIRIM SELECTOR

            // =====================================================

            await client.sendIAMessage(

                m.chat,

                buttons,

                m,

                {

                    header: "AIO Downloader",

                    content: `🎬 ${r.title || "AIO Result"}\nSilakan pilih media:`,

                    footer: "© rizk.my.id • AIO Downloader"

                    // Tidak pakai media header → supaya tidak error

                }

            );

        } catch (e) {

            console.log("AIO Error:", e);

            // Menampilkan error jika response API tidak sesuai

            return client.reply(m.chat, Utils.jsonFormat(e));

        }

    },

    error: false

};

