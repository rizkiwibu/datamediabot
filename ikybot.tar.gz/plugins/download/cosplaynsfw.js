import axios from "axios";

import { load } from "cheerio";

import { setCode } from "../../lib/cosplay.store.js";

const footer = "© FOLOW IG ADMIN YAK @IKUKUNNNN";

const BASE_URL = "https://cosplaytele.com";

const TELEGRAM_BOT = "https://t.me/hayolohngapain_bot"; // GANTI INI

function generateCode() {

  return Math.random().toString(36).substring(2, 8).toUpperCase();

}

// ==========================

// SCRAPER CORE

// ==========================

async function extract(url) {

  try {

    const { data } = await axios.get(url);

    return load(data);

  } catch (e) {

    console.log("SCRAPE ERROR:", e.message);

    return null;

  }

}

async function latest(page = 1) {

  const $ = await extract(`${BASE_URL}/page/${page}/`);

  if (!$) return [];

  const results = [];

  $(".col.post-item").each((_, el) => {

    const $el = $(el);

    results.push({

      title: $el.find(".post-title a").text().trim(),

      url: $el.find(".post-title a").attr("href"),

      excerpt: $el.find(".from_the_blog_excerpt").text().trim()

    });

  });

  return results;

}

async function search(query) {

  const $ = await extract(`${BASE_URL}/?s=${encodeURIComponent(query)}`);

  if (!$) return [];

  const results = [];

  $(".col.post-item").each((_, el) => {

    const $el = $(el);

    results.push({

      title: $el.find(".post-title a").text().trim(),

      url: $el.find(".post-title a").attr("href"),

      excerpt: $el.find(".from_the_blog_excerpt").text().trim()

    });

  });

  return results;

}

async function detail(url) {

  const $ = await extract(url);

  if (!$) return null;

  const data = {

    title: $("h1").first().text().trim(),

    images: [],

    details: {}

  };

  $(".entry-content").first().find("img").each((_, el) => {

    const src =

      $(el).attr("data-src") ||

      $(el).attr("data-lazy-src") ||

      $(el).attr("src");

    if (!src) return;

    if (src.match(/\.(webp|jpg|jpeg|png|gif)$/i)) {

      data.images.push(src);

    }

  });

  data.images = [...new Set(data.images)];

  const excerpt = $(".from_the_blog_excerpt").first().text().trim();

  const detailsMap = {

    Cosplayer: "cosplayer",

    Character: "character",

    "Appear In": "appearance",

    Photos: "photos",

    "File Size": "fileSize",

    "Unzip Password": "password"

  };

  excerpt.split("\n").forEach((line) => {

    if (!line.includes(":")) return;

    const [keyPart, ...valueParts] = line.split(":");

    const key = detailsMap[keyPart.trim()];

    if (key) data.details[key] = valueParts.join(":").trim();

  });

  return data;

}

// ==========================

// PLUGIN RUN

// ==========================

export const run = {

  usage: ["cosplaynsfw"],

  use: "search <nama> | latest <page>",

  category: "nsfw",

  async: async (m, { client, text, isPrefix, command, Utils }) => {

    try {

      if (!text)

        return client.reply(

          m.chat,

          Utils.example(isPrefix, command, "search nagato"),

          m

        );

      client.sendReact(m.chat, "⏳", m.key);

      // ==========================

      // SEARCH

      // ==========================

      if (text.startsWith("search")) {

        const query = text.replace("search", "").trim();

        const res = await search(query);

        if (!res.length) {

          client.sendReact(m.chat, "❌", m.key);

          return client.reply(m.chat, "❌ Data tidak ditemukan.", m);

        }

        const rows = res.map(v => ({

          title: v.title,

          description: v.excerpt.substring(0, 60),

          id: `${isPrefix + command} detail ${v.url}`

        }));

        const listParams = {

          title: "PILIH COSPLAY",

          sections: [{

            title: "Hasil Pencarian",

            rows

          }]

        };

        const buttons = [{

          name: "single_select",

          buttonParamsJson: JSON.stringify(listParams)

        }];

        await client.sendIAMessage(

          m.chat,

          buttons,

          m,

          {

            header: "COSPLAY NSFW — SEARCH",

            content: `Query: ${query}\n\nTotal ${rows.length} hasil`,

            footer

          }

        );

        return client.sendReact(m.chat, "✅", m.key);

      }

      // ==========================

      // DETAIL → KODE TELEGRAM

      // ==========================

      if (text.startsWith("detail")) {

        const url = text.replace("detail", "").trim();

        const res = await detail(url);

        if (!res || !res.images.length) {

          client.sendReact(m.chat, "❌", m.key);

          return client.reply(

            m.chat,

            "❌ Gagal mengambil detail / gambar kosong.",

            m

          );

        }

        const index = Math.floor(Math.random() * res.images.length);

        const code = generateCode();

        await setCode(code, { url, index });

        const tgLink = `${TELEGRAM_BOT}?start=cos_${code}`;

        let captionText = `🔞 *COSPLAY NSFW — TELEGRAM AKSES*\n\n`;

        captionText += `📌 *Judul:* ${res.title}\n`;

        if (res.details.cosplayer)

          captionText += `👤 Cosplayer: ${res.details.cosplayer}\n`;

        if (res.details.character)

          captionText += `🎭 Character: ${res.details.character}\n`;

        captionText += `\n📥 Ambil konten via Telegram:\n${tgLink}\n\n`;

        captionText += `⚠️ Link hanya berlaku *1x pakai*\n\n`;

        captionText += footer;

        await client.reply(m.chat, captionText.trim(), m);

        return client.sendReact(m.chat, "✅", m.key);

      }

      // ==========================

      // LATEST

      // ==========================

      if (text.startsWith("latest")) {

        const page = Number(text.replace("latest", "").trim()) || 1;

        const res = await latest(page);

        if (!res.length) {

          client.sendReact(m.chat, "❌", m.key);

          return client.reply(m.chat, "❌ Tidak ada update.", m);

        }

        const rows = res.map(v => ({

          title: v.title,

          description: v.excerpt.substring(0, 60),

          id: `${isPrefix + command} detail ${v.url}`

        }));

        rows.push({

          title: "Next ▶️",

          description: `Page ${page + 1}`,

          id: `${isPrefix + command} latest ${page + 1}`

        });

        const listParams = {

          title: "UPDATE TERBARU",

          sections: [{

            title: `Page ${page}`,

            rows

          }]

        };

        const buttons = [{

          name: "single_select",

          buttonParamsJson: JSON.stringify(listParams)

        }];

        await client.sendIAMessage(

          m.chat,

          buttons,

          m,

          {

            header: "COSPLAY NSFW — LATEST",

            content: `Update halaman ${page}`,

            footer

          }

        );

        return client.sendReact(m.chat, "✅", m.key);

      }

    } catch (e) {

      console.error(e);

      client.sendReact(m.chat, "❌", m.key);

      return client.reply(m.chat, Utils.jsonFormat(e), m);

    }

  },

  error: false,

  limit: true,

  premium: true

};