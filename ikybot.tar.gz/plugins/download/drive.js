import axios from 'axios';

// --- FUNGSI CORE: DRIVEDL (Diubah menjadi fungsi internal) ---
/**
 * Mendapatkan metadata dan URL download dari Google Drive file/folder.
 * @param {string} url - URL atau ID Google Drive file/folder.
 * @returns {Promise<object>} Detail file, folder, atau isinya.
 */
async function drivedl(url) {
    try {
        // 💡 Catatan: API Key ini tetap di-hardcode di sini. Sebaiknya letakkan di process.env jika bisa.
        const API_KEY = 'AIzaSyAA9ERw-9LZVEohRYtCWka_TQc6oXmvcVU'; 
        
        const extractFileId = (driveUrl) => {
            const patterns = [
                /\/file\/d\/([a-zA-Z0-9_-]+)/,
                /id=([a-zA-Z0-9_-]+)/,
                /folders\/([a-zA-Z0-9_-]+)/,
                /^([a-zA-Z0-9_-]+)$/
            ];
            
            for (const pattern of patterns) {
                const match = driveUrl.match(pattern);
                if (match) return match[1];
            }
            return null;
        };
        
        const fileId = extractFileId(url);
        if (!fileId) throw new Error('Invalid Google Drive URL or ID.');
        
        // 1. Ambil Metadata
        const { data: metadata } = await axios.get(`https://www.googleapis.com/drive/v3/files/${fileId}?key=${API_KEY}&fields=id,name,mimeType,size,webContentLink,owners,createdTime`);
        
        // 2. Jika Folder
        if (metadata.mimeType === 'application/vnd.google-apps.folder') {
            const { data: list } = await axios.get(`https://www.googleapis.com/drive/v3/files?key=${API_KEY}&q='${fileId}'+in+parents&fields=files(id,name,mimeType,size,owners,createdTime)`);
            const files = list.files || [];
            
            return {
                type: 'folder',
                details: {
                    id: metadata.id,
                    name: metadata.name,
                    mimeType: metadata.mimeType,
                    createdTime: metadata.createdTime,
                    totalFiles: files.length,
                    owner: metadata.owners && metadata.owners[0] ? {
                        name: metadata.owners[0].displayName,
                        email: metadata.owners[0].emailAddress,
                        photoLink: metadata.owners[0].photoLink
                    } : null
                },
                contents: files.filter(file => !file.mimeType.includes('application/vnd.google-apps.folder')).map(file => ({
                    id: file.id,
                    name: file.name,
                    mimeType: file.mimeType,
                    size: file.size ? `${(file.size / 1024 / 1024).toFixed(2)} MB` : 'N/A',
                    createdTime: file.createdTime,
                    downloadUrl: `https://www.googleapis.com/drive/v3/files/${file.id}?alt=media&key=${API_KEY}`
                }))
            };
        } 
        
        // 3. Jika File
        else {
            return {
                type: 'file',
                details: {
                    id: metadata.id,
                    name: metadata.name,
                    mimeType: metadata.mimeType,
                    size: metadata.size ? `${(metadata.size / 1024 / 1024).toFixed(2)} MB` : 'N/A',
                    createdTime: metadata.createdTime,
                    owner: metadata.owners && metadata.owners[0] ? {
                        name: metadata.owners[0].displayName,
                        email: metadata.owners[0].emailAddress,
                        photoLink: metadata.owners[0].photoLink
                    } : null
                },
                downloadUrl: `https://www.googleapis.com/drive/v3/files/${metadata.id}?alt=media&key=${API_KEY}`,
                directDownload: metadata.webContentLink
            };
        }
    } catch (error) {
        const errorMsg = error.response?.data?.error?.message || error.message;
        throw new Error(errorMsg);
    }
};

// --- PLUGIN BOT UTAMA ---
export const run = {
   usage: ['drive', 'drivedl', 'gdl'],
   use: 'url',
   category: 'downloader',
   cooldown: 10,
   limit: true,
   async: async (m, {
      client,
      text, 
      isPrefix,
      command,
      Utils
   }) => {
      try {
         const url = text?.trim();
         
         if (!url) {
            return client.reply(m.chat, Utils.example(isPrefix, command, 'https://drive.google.com/file/d/xxxxx/view'), m)
         }
         
         client.sendReact(m.chat, '🕒', m.key);

         const result = await drivedl(url); // Menggunakan fungsi internal drivedl
         
         let responseMsg = '';
         
         if (result.type === 'file') {
            const { details, downloadUrl } = result;
            responseMsg = `
📁 *GOOGLE DRIVE DOWNLOADER (FILE)*

*Nama:* ${details.name}
*Tipe:* ${details.mimeType}
*Ukuran:* ${details.size}
*ID:* ${details.id}
*Owner:* ${details.owner ? details.owner.name : 'N/A'}

🔗 *Link Download:*
${downloadUrl}
            `.trim();
            
            // Logika pengiriman file (di bawah 50 MB)
            const sizeInMB = parseFloat(details.size.replace(' MB', ''));
            
            if (sizeInMB < 50) {
               client.reply(m.chat, `✅ Mengirim file: *${details.name}* (${details.size}).`, m);
               
               await client.sendMessage(m.chat, {
                  document: { url: downloadUrl },
                  fileName: details.name,
                  mimetype: details.mimeType,
                  caption: `✅ File berhasil didownload: ${details.name}`
               }, { quoted: m });
               
            } else {
               // Jika terlalu besar, kirim hanya URL
               responseMsg += "\n\n❗ *File terlalu besar (>50 MB), silakan unduh langsung dari link di atas.*";
               client.reply(m.chat, responseMsg, m);
            }

         } else if (result.type === 'folder') {
            const { details, contents } = result;
            
            responseMsg = `
📂 *GOOGLE DRIVE DOWNLOADER (FOLDER)*

*Nama:* ${details.name}
*ID:* ${details.id}
*Total File:* ${details.totalFiles}
*Owner:* ${details.owner ? details.owner.name : 'N/A'}
*Dibuat:* ${new Date(details.createdTime).toLocaleDateString()}

*📄 Isi Folder (Non-Folder):*
${contents.map((file, i) => 
   `${i + 1}. *${file.name}* (${file.size})`
).join('\n')}

*❗ Terdapat ${contents.length} file yang dapat diunduh. Silakan salin ID file dan gunakan command ini untuk mengunduh per file.*
            `.trim();
            
            client.reply(m.chat, responseMsg, m);
            
            const sampleLinks = contents.slice(0, 3).map(file => `- ${file.name}: ${file.downloadUrl}`).join('\n');
            if (sampleLinks) {
                client.reply(m.chat, `🔗 *Contoh Link Download (3 File Pertama):*\n${sampleLinks}`, m);
            }
         }
         
         client.sendReact(m.chat, '✅', m.key);

      } catch (e) {
         console.error("Drive DL Error:", e);
         client.sendReact(m.chat, '❌', m.key);
         const errorMessage = e.message.includes('404') ? 'File atau folder tidak ditemukan atau tidak memiliki akses publik.' : e.message;
         return client.reply(m.chat, Utils.texted('bold', `❌ Gagal: ${errorMessage}`), m);
      }
   },
   error: false,
   limit: true
}
