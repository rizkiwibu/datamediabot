import axios from 'axios';
import { load } from 'cheerio'; // Menggunakan named import 'load' untuk menghindari error
import qs from 'qs';

// 1. Fungsi Scraper Facebook
async function asu(url) {
  try {
    const payload = qs.stringify({ fb_url: url });
    const res = await axios.post("https://saveas.co/smart_download.php", payload, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"
      }
    });
    
    const $ = load(res.data); 
    
    if (!$("#sdLink").length && !$("#hdLink").length) {
        return { status: "error", message: "Gagal menemukan tautan unduhan. Pastikan video bersifat publik." };
    }

    const thumb = $(".box img").attr("src") || null;
    const title = $(".box .info h2").text().trim() || 'Judul Tidak Diketahui';
    const desc = $(".box .info p").first().text().replace("Description:", "").trim() || 'N/A';
    const duration = $(".box .info p").last().text().replace("Duration:", "").trim() || 'N/A';
    const sd = $("#sdLink").attr("href") || null;
    const hd = $("#hdLink").attr("href") || null;

    return { status: "success", title, desc, duration, thumb, sd, hd };
  } catch (e) {
    console.error("Scraper Error:", e);
    return { status: "error", message: `Kesalahan saat scraping: ${e.message}` };
  }
}

// 2. Struktur Fitur Bot WA
export const run = {
   usage: ['fbdl', 'fb'],
   use: 'link', 
   category: 'downloader',
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      Utils
   }) => {
      try {
         if (!text || !Utils.isUrl(text) || !text.includes('facebook.com')) {
             return client.reply(m.chat, Utils.example(isPrefix, command, 'https://www.facebook.com/watch/?v=1234567890'), m);
         }
         
         client.sendReact(m.chat, '🕒', m.key); 
         
         const data = await asu(text);

         if (data.status === "error") {
             client.sendReact(m.chat, '❌', m.key);
             return client.reply(m.chat, Utils.texted('bold', `❌ Gagal memproses: ${data.message}`), m);
         }

         const { title, thumb, sd, hd } = data;
         const downloadUrl = hd || sd;

         if (!downloadUrl) {
             client.sendReact(m.chat, '⚠️', m.key);
             return client.reply(m.chat, Utils.texted('bold', `⚠️ Gagal mendapatkan tautan video. Coba tautan lain.`), m);
         }

         // HAPUS: Tidak ada lagi client.reply() untuk detail teks.

         // Mengirim video langsung dengan caption sederhana
         await client.sendMessage(m.chat, {
             video: { url: downloadUrl }, 
             caption: `✅ Berhasil didownload: *${title}*`, 
             mimetype: "video/mp4",
             fileName: `${title}.mp4`,
             contextInfo: {
                 externalAdReply: {
                     title: title,
                     body: "Video Facebook Downloader",
                     thumbnailUrl: thumb,
                     mediaType: 2,
                     renderLargerThumbnail: true,
                 },
             },
         }, {
             quoted: m,
         });

         client.sendReact(m.chat, '✅', m.key);

      } catch (e) {
         console.error("FBDL Error:", e);
         client.sendReact(m.chat, '🚩', m.key);
         client.reply(m.chat, Utils.texted('bold', `🚩 Terjadi kesalahan tak terduga: Gagal memproses download video FB.`), m);
      }
   },
   error: false,
   limit: true,
   cooldown: 5 
}
