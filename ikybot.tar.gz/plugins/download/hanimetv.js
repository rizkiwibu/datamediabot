import fs from "fs";

import HanimeScraper from "../../lib/hnimescraper.js";

const LOCAL_THUMB = "./media/image/18+.jpg";

// =========================

//  Extract Video Streams FIX

// =========================

function extractStreams(detail) {

    let streams = [];

    // 1. videos_manifest → servers[].streams[]

    const servers = detail?.videos_manifest?.servers || [];

    for (const srv of servers) {

        if (srv?.streams) {

            for (const s of srv.streams) {

                if (s.url) {

                    streams.push({

                        height: s.height,

                        size: s.filesize_mbs || null,

                        url: s.url

                    });

                }

            }

        }

    }

    // 2. hentai_video.videos

    const directVideos = detail?.hentai_video?.videos || [];

    for (const v of directVideos) {

        if (v.url) {

            streams.push({

                height: v.height,

                size: v.filesize_mbs || null,

                url: v.url

            });

        }

    }

    // 3. hentai_video.video_qualities

    const ql = detail?.hentai_video?.video_qualities || {};

    for (const k of Object.keys(ql)) {

        const v = ql[k];

        if (v?.url) {

            streams.push({

                height: v.height,

                size: v.filesize_mbs || null,

                url: v.url

            });

        }

    }

    // Filter tanpa URL

    streams = streams.filter(v => v.url);

    // Remove duplicate URL

    const seen = new Set();

    streams = streams.filter(v => {

        if (seen.has(v.url)) return false;

        seen.add(v.url);

        return true;

    });

    return streams;

}

// =========================

//  MAIN COMMAND

// =========================

export const run = {

    usage: ["hanime"],

    use: "query / slug / nomor",

    category: "nsfw",

    async: async (m, { client, text, isPrefix, Utils }) => {

        try {

            if (!text)

                return m.reply(

                    `🎥 *Cara Pakai Hanime*\n\n` +

                    `${isPrefix}hanime kanna\n` +

                    `${isPrefix}hanime uma-musume-pretty-derby-star-blossom`

                );

            // =============================

            // 1 — PEMILIHAN DARI SEARCH LIST (ANGKA)

            // =============================

            if (!isNaN(text)) {

                const cache = global._hanime?.[m.sender];

                if (!cache) return m.reply("⚠️ List tidak ditemukan. Ulangi pencarian.");

                const index = Number(text);

                const selected = cache[index];

                if (!selected) return m.reply("⚠️ Nomor tidak valid.");

                const slug = selected.slug;

                const detail = await HanimeScraper.detail(slug);

                // Ambil semua streaming

                const streams = extractStreams(detail);

                if (!streams.length)

                    return m.reply("❌ Stream video tidak tersedia.");

                const rows = streams.map((v, i) => ({

                    title: `${v.height}p`,

                    description: v.size ? `${v.size} MB` : "",

                    id: `${isPrefix}hanime_quality ${slug} ${i}`

                }));

                const buttons = [{

                    name: "single_select",

                    buttonParamsJson: JSON.stringify({

                        title: "Pilih Kualitas Video",

                        sections: [{

                            title: "Hanime Quality",

                            rows

                        }]

                    })

                }];

                const thumb = fs.existsSync(LOCAL_THUMB)

                    ? LOCAL_THUMB

                    : null;

                await client.sendIAMessage(

                    m.chat,

                    buttons,

                    m,

                    {

                        header: "Quality Selector",

                        content: `🎬 ${detail.hentai_video.name}\nSilakan pilih kualitas video:`,

                        footer: "© rizk.my.id",

                        media: thumb

                    }

                );

                return;

            }

            // =============================

            // 2 — PEMILIHAN KUALITAS VIDEO

            // =============================

            if (text.startsWith("hanime_quality")) {

                const [_cmd, slug, index] = text.split(" ");

                const detail = await HanimeScraper.detail(slug);

                const streams = extractStreams(detail);

                const selected = streams[Number(index)];

                if (!selected)

                    return m.reply("❌ Kualitas tidak ditemukan.");

                return await client.sendFile(

                    m.chat,

                    selected.url,

                    `${slug}-${selected.height}p.mp4`,

                    `🎬 *${detail.hentai_video.name}*\n📹 *${selected.height}p*`,

                    m

                );

            }

            // =============================

            // 3 — USER INPUT SLUG LANGSUNG

            // =============================

            if (!text.includes(" ")) {

                try {

                    const detail = await HanimeScraper.detail(text);

                    const streams = extractStreams(detail);

                    if (!streams.length) return m.reply("❌ Video tidak tersedia.");

                    const rows = streams.map((v, i) => ({

                        title: `${v.height}p`,

                        description: v.size ? `${v.size} MB` : "",

                        id: `${isPrefix}hanime_quality ${text} ${i}`

                    }));

                    const buttons = [{

                        name: "single_select",

                        buttonParamsJson: JSON.stringify({

                            title: "Pilih Kualitas Video",

                            sections: [{ title: "Hanime Quality", rows }]

                        })

                    }];

                    const thumb = fs.existsSync(LOCAL_THUMB)

                        ? LOCAL_THUMB

                        : null;

                    await client.sendIAMessage(

                        m.chat,

                        buttons,

                        m,

                        {

                            header: "Hanime Quality Menu",

                            content: `🎬 *${detail.hentai_video.name}*\nTersedia ${streams.length} kualitas.`,

                            footer: "© rizk.my.id",

                            media: thumb

                        }

                    );

                    return;

                } catch (e) {}

            }

            // =============================

            // 4 — MODE PENCARIAN

            // =============================

            const result = await HanimeScraper.search(text);

            const hits = result.hits || [];

            if (!hits.length)

                return m.reply("❌ Tidak ada hasil ditemukan.");

            global._hanime ??= {};

            global._hanime[m.sender] = hits;

            const rows = hits.map((v, i) => ({

                title: `${i}. ${v.name}`,

                description: v.hentai_tags?.map(t => t.tag_name).join(", ").slice(0, 60),

                id: `${isPrefix}hanime ${i}`

            }));

            const buttons = [{

                name: "single_select",

                buttonParamsJson: JSON.stringify({

                    title: "Hasil Pencarian Hanime",

                    sections: [{ title: "Pilih Judul", rows }]

                })

            }];

            const thumb = fs.existsSync(LOCAL_THUMB)

                ? LOCAL_THUMB

                : null;

            await client.sendIAMessage(

                m.chat,

                buttons,

                m,

                {

                    header: "Hanime Search",

                    content: `🔍 *HANIME SEARCH*\nQuery: *${text}*\nHasil: *${hits.length}*\nKlik tombol untuk memilih.`,

                    footer: "© rizk.my.id",

                    media: thumb

                }

            );

        } catch (e) {

            console.log("Hanime error:", e);

            client.reply(m.chat, Utils.jsonFormat(e), m);

        }

    },

    error: false,

    limit: true,

    premium: true

};