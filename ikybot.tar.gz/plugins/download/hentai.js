import axios from "axios";

import fs from "fs";

const THUMB = fs.readFileSync("./media/image/18+.jpg");

export const run = {

   usage: ['hentaivid', 'hentaivideo'],

   use: 'hentaivideo',

   category: 'nsfw',

   async: async (m, { client, isPrefix, command, text, Utils }) => {

      try {

         

         // ===============================

         // CASE 1 — USER MEMILIH VIDEO

         // ===============================

         if (text && !isNaN(text)) {

            const index = Number(text);

            const vids = global._hentaiv?.[m.sender];

            if (!vids || !vids[index])

                return m.reply("❌ List expired! ketik *hentaivideo* lagi.");

            const v = vids[index];

            const video = v.video_1 || v.video_2;

            await client.sendFile(

               m.chat,

               video,

               "hentai.mp4",

               `🎬 *${v.title}*\n📂 ${v.category}\n👀 ${v.views_count}\n\nEnjoy 🔞`,

               m

            );

            return;

         }

         // ===============================

         // CASE 2 — USER MINTA LIST

         // ===============================

         const API = "https://restapi.rizk.my.id/sfwnsfw/hentaivideo?apikey=vip";

         const { data } = await axios.get(API);

         if (!data.status) return m.reply("❌ Gagal mengambil data!");

         const vids = data.data;

         global._hentaiv ??= {};

         global._hentaiv[m.sender] = vids;

         const rows = vids.map((v, i) => ({

            title: `${i + 1}. ${v.title}`,

            description: `${v.category} • ${v.views_count}`,

            id: `${isPrefix}hentaivideo ${i}`

         }));

         const buttons = [{

            name: "single_select",

            buttonParamsJson: JSON.stringify({

               title: "Pilih Hentai 🔞",

               sections: [{

                  title: "List Video",

                  rows

               }]

            }),

         }];

         const caption = `*Hentai Video 🔞*\n\nTotal: ${vids.length}\nPilih salah satu dari list di bawah:`;

         await client.sendIAMessage(

            m.chat,

            buttons,

            m,

            {

               header: "Hentai Video List 🔞",

               content: caption,

               footer: "© rizk.my.id",

               media: THUMB

            }

         );

      } catch (e) {

         console.log(e);

         return m.reply(Utils.jsonFormat(e));

      }

   },

   error: false,

   limit: true,

   premium: true

};