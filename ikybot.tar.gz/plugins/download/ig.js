import axios from "axios";

export const run = {

    usage: ["ig"],

    use: "url",

    category: "downloader",

    cooldown: 5,

    limit: true,

    async: async (m, { client, text, isPrefix, command, Utils }) => {

        try {

            const url = text?.trim();

            if (!url)

                return client.reply(

                    m.chat,

                    Utils.example(isPrefix, command, "https://www.instagram.com/reel/xxxx"),

                    m

                );

            client.sendReact(m.chat, "⏳", m.key);

            const api = `https://backend1.tioo.eu.org/igdl?url=${encodeURIComponent(url)}`;

            const { data } = await axios.get(api);

            if (!Array.isArray(data) || data.length === 0 || !data[0].status) {

                client.sendReact(m.chat, "❌", m.key);

                return client.reply(

                    m.chat,

                    "❌ Tidak ada media ditemukan dari API.",

                    m

                );

            }

            const res = data[0];

            // --- KIRIM THUMBNAIL ---

            if (res.thumbnail) {

                await client.sendMessage(

                    m.chat,

                    {

                        image: { url: res.thumbnail },

                        caption: `📸 *Instagram Downloader*\nCreator: @ikykunnnn`,

                    },

                    { quoted: m }

                );

            }

            // --- KIRIM VIDEO ---

            await client.sendMessage(

                m.chat,

                {

                    video: { url: res.url },

                    caption: "🎥 Video Instagram",

                },

                { quoted: m }

            );

            client.sendReact(m.chat, "✅", m.key);

        } catch (err) {

            client.sendReact(m.chat, "❌", m.key);

            client.reply(m.chat, `❌ Error: ${err.message}`, m);

        }

    },

    error: false,

};