import axios from "axios";

import * as cheerio from "cheerio";

// Konfigurasi Footer

const footer = '©jangan lupa folow ig ikykunnnn';

export const run = {

  usage: ["lirik", "shazam"],

  use: "judul lagu | link shazam",

  category: "tools",

  async: async (m, { client, text, isPrefix, command, Utils }) => {

    try {

      if (!text)

        return client.reply(

          m.chat,

          `Contoh penggunaan:\n${isPrefix + command} Bernafas Tanpamu\n\nAtau tempel link shazam langsung.`,

          m

        );

      // Loading reaction

      client.sendReact(m.chat, "⏳", m.key);

      // ==========================

      // Mode 1: DETAIL LIRIK (Jika input adalah Link Shazam)

      // ==========================

      if (text.includes("shazam.com/")) {

        const res = await shazam.lyrics(text);

        

        if (!res.lyrics) {

          client.sendReact(m.chat, "❌", m.key);

          return client.reply(m.chat, "❌ Lirik tidak ditemukan untuk lagu ini.", m);

        }

        let caption = `*SHAZAM LYRICS*\n\n`;

        caption += `🎵 *Judul:* ${res.title || '-'}\n`;

        caption += `👤 *Artis:* ${res.artist || '-'}\n`;

        caption += `💿 *Album:* ${res.album || '-'}\n`;

        caption += `📅 *Rilis:* ${res.releaseDate || '-'}\n`;

        caption += `✨ *Genre:* ${res.genre || '-'}\n\n`;

        caption += `─── *LIRIK* ───\n\n${res.lyrics}`;

        // Kirim lirik beserta cover jika ada

        if (res.cover) {

          await client.sendMessage(m.chat, { image: { url: res.cover }, caption: caption }, { quoted: m });

        } else {

          await client.reply(m.chat, caption, m);

        }

        return client.sendReact(m.chat, "✅", m.key);

      }

      // ==========================

      // Mode 2: SEARCH (Jika input adalah teks/judul)

      // ==========================

      const results = await shazam.search(text);

      if (!results || results.length === 0) {

        client.sendReact(m.chat, "❌", m.key);

        return client.reply(m.chat, `❌ Lagu "${text}" tidak ditemukan!`, m);

      }

      // --- Persiapan List Message ---

      let rows = results.map(v => ({

        title: v.title,

        description: `Artis: ${v.artist} | Album: ${v.album}`,

        id: `${isPrefix}${command} ${v.url}` // Perintah untuk mengambil lirik

      }));

      const listParams = {

        title: "HASIL PENCARIAN",

        sections: [{

          title: "Pilih lagu untuk melihat lirik",

          rows: rows

        }]

      };

      const buttons = [{

        name: "single_select",

        buttonParamsJson: JSON.stringify(listParams),

      }];

      let content = `*SHAZAM SEARCH*\n\nQuery: _${text}_\n\nSilakan pilih lagu di bawah ini untuk mendapatkan lirik lengkapnya:`;

      // --- KIRIM LIST MESSAGE ---

      await client.sendIAMessage(

        m.chat,

        buttons,

        m,

        {

          header: 'Shazam Music Finder',

          content: content,

          footer: footer,

          // media: results[0].cover // Opsional: gunakan cover hasil pertama sebagai header

        }

      );

      return client.sendReact(m.chat, "✅", m.key);

    } catch (e) {

      console.error(e);

      client.sendReact(m.chat, "❌", m.key);

      client.reply(m.chat, "❌ Terjadi kesalahan saat memproses permintaan.", m);

    }

  },

  error: false,

  limit: true,

  cooldown: 3,

};

// ==========================

// UTILS & SCRAPER FUNCTIONS

// ==========================

function slugify(text = '') {

  return text

    .toLowerCase()

    .replace(/[^a-z0-9]+/g, '-')

    .replace(/(^-|-$)/g, '')

}

const shazam = {

  async search(query, limit = 5) {

    try {

      const { data } = await axios.get(

        `https://www.shazam.com/services/amapi/v1/catalog/ID/search`,

        {

          params: {

            types: 'songs',

            term: query,

            limit

          }

        }

      )

      const songs = data?.results?.songs?.data || []

      return songs.map(v => ({

        id: v.id,

        title: v.attributes.name,

        artist: v.attributes.artistName,

        album: v.attributes.albumName,

        cover: v.attributes.artwork?.url

          ?.replace('{w}', '500')

          ?.replace('{h}', '500'),

        url: `https://www.shazam.com/id-id/song/${v.id}/${slugify(v.attributes.name)}?tab=lyrics`

      }))

    } catch (e) {

      return [];

    }

  },

  async lyrics(url) {

    try {

      const { data: html } = await axios.get(url, {

        headers: {

          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',

          'Accept-Language': 'en-US,en;q=0.9'

        }

      })

      const $ = cheerio.load(html)

      const song = {}

      const jsonLd = $('script[type="application/ld+json"]').html()

      if (jsonLd) {

        const j = JSON.parse(jsonLd)

        song.title = j.name

        song.artist = j.byArtist?.name

        song.album = j.inAlbum?.name

        song.releaseDate = j.datePublished

        song.genre = j.genre

        song.cover = j.thumbnailUrl

      }

      const lyrics = []

      // Selector terbaru untuk lirik di web Shazam

      $('.LyricsContent_lyricSection__ciW_E').each((_, el) => {

        const text = $(el)

          .find('.LyricsContent_lyricLine__pSlCU')

          .map((_, l) => $(l).text().trim())

          .get()

          .join('\n')

        if (text) lyrics.push(text)

      })

      song.lyrics = lyrics.join('\n\n') || null

      return song

    } catch (e) {

      return { lyrics: null };

    }

  }

}

