import axios from 'axios'

export const run = {
   // Mengubah command, usage, dan category sesuai format baru
   usage: ['mediafire', 'mf'],
   use: 'url',
   category: 'downloader',
   cooldown: 5,
   limit: true,
   async: async (m, {
      client,
      text, // Menggunakan 'text' dari parameter baru
      isPrefix,
      command,
      Utils
   }) => {
      try {
         const url = text?.trim();

         // 1. Pengecekan Input dan URL
         if (!url) {
            return client.reply(m.chat, Utils.example(isPrefix, command, 'https://www.mediafire.com/file/xxxxx'), m)
         }

         if (!/^https:\/\/www\.mediafire\.com\/file\//i.test(url)) {
            return client.reply(m.chat, Utils.texted('bold', "⚠️ URL tidak valid! Harap gunakan link MediaFire yang benar."), m)
         }

         // 2. Memberikan reaksi 'jam' untuk indikator loading
         client.sendReact(m.chat, '🕒', m.key)

         // 3. Mengganti fetch dengan axios
         const apiUrl = `https://api.nekolabs.web.id/downloader/mediafire?url=${encodeURIComponent(url)}`;
         
         const { data: json } = await axios.get(apiUrl);

         if (!json.success || !json.result?.download_url)
            throw new Error("Tidak dapat mengambil informasi file dari MediaFire.");

         const { filename, mimetype, download_url, filesize } = json.result; // Menambahkan filesize jika tersedia

         // 4. Mengirim file sebagai dokumen menggunakan client.sendMessage
         await client.sendMessage(m.chat, {
            document: { url: download_url }, // Mengirim file sebagai dokumen
            fileName: filename,
            mimetype: mimetype || "application/octet-stream",
            caption: `📁 *${filename}*\n${filesize ? `📦 Ukuran: ${filesize}\n` : ''}\n✅ Berhasil diunduh dari MediaFire.`,
         }, {
            quoted: m,
         });

         // 5. Mengganti reaksi loading dengan '✅'
         client.sendReact(m.chat, '✅', m.key)

      } catch (e) {
         console.error("MediaFire Downloader Error:", e);
         // 6. Mengganti reaksi loading dengan '❌'
         client.sendReact(m.chat, '❌', m.key)
         client.reply(m.chat, Utils.texted('bold', `🚩 Terjadi kesalahan: ${e.message}`), m)
      }
   },
   error: false,
}
