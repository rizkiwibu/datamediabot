import axios from "axios";

import { load } from "cheerio";

// Asumsi: Variabel global.footer tersedia di lingkungan bot Anda.

// Jika tidak, ganti dengan string footer yang sesuai.

const footer = '© FOLOW IG ADMIN YAK @IKUKUNNNN'; 

export const run = {

  usage: ["otakudesu"],

  use: "nama_anime|link",

  category: "anime",

  async: async (m, { client, text, isPrefix, command, Utils }) => {

    try {

      if (!text)

        return client.reply(

          m.chat,

          Utils.example(isPrefix, command, "kaguya-sama"),

          m

        );

      // Loading reaction

      client.sendReact(m.chat, "⏳", m.key);

      // ==========================

      // Mode 1: DETAIL ANIME (Link) - Menggunakan List Message

      // ==========================

      if (text.includes("/anime/")) {

        const res = await detail(text);

        if (res.code !== 200) {

          client.sendReact(m.chat, "❌", m.key);

          return client.reply(m.chat, "❌ Gagal mengambil detail anime!", m);

        }

        const { thumb, text: info, links } = res.data;

        // --- Persiapan List Message ---

        let rows = links.map(v => ({

            title: v.name,

            description: `Link: ${v.link.length > 50 ? v.link.substring(0, 50) + '...' : v.link}`,

            id: `${isPrefix}otakudesu ${v.link}` // Perintah yang akan dieksekusi

        }));

        const listParams = {

            title: "PILIH EPISODE",

            sections: [{

                title: "Daftar Episode",

                rows: rows

            }]

        };

        const buttons = [{

            name: "single_select",

            buttonParamsJson: JSON.stringify(listParams),

        }];

        let caption = `*OTAKUDESU — DETAIL ANIME*\n\n${info}\n\n*Total Episode: ${links.length}*\nSilakan klik tombol di bawah untuk memilih episode:`;

        

        // --- KIRIM LIST MESSAGE DENGAN client.sendIAMessage ---

        await client.sendIAMessage(

              m.chat, 

              buttons, 

              m, 

              {

                header: 'Detail Anime Otakudesu',

                content: caption,

                footer: footer,

                media: thumb // URL Gambar sebagai thumbnail

              }

            );

        // --------------------------------------------------------

        

        return client.sendReact(m.chat, "✅", m.key);

      }

      // ==========================

      // Mode 2: EPISODE LINK & DOWNLOAD FILE

      // ==========================

      if (text.includes("/episode/")) {

        const res = await link(text);

        if (res.code !== 200) {

          client.sendReact(m.chat, "❌", m.key);

          return client.reply(m.chat, "❌ Tidak dapat mengambil link episode!", m);

        }

        let caption = `*OTAKUDESU — LINK EPISODE*\n🎬 ${res.data.anime}`;

        let downloadLink = null;

        let downloadText = "";

        res.data.list.forEach((v) => {

            caption += `\n\n• ${v.reso}\n${v.link}`;

            

            if (!downloadLink) {

                const linksArray = v.link.split('\n');

                for (const linkItem of linksArray) {

                    if (linkItem.toLowerCase().includes("mp4") || linkItem.toLowerCase().includes("mkv")) {

                        // Ambil URL-nya saja

                        const urlMatch = linkItem.match(/(https?:\/\/[^\s]+)/);

                        if (urlMatch) {

                           downloadLink = urlMatch[0].trim();

                        }

                        downloadText = v.reso;

                        break;

                    }

                }

            }

        });

        await client.reply(m.chat, caption, m);

        

        // KIRIM FILE LANGSUNG

        if (downloadLink) {

            client.sendReact(m.chat, "💾", m.key);

            await client.reply(m.chat, `*Mencoba mengirim file ${downloadText}..*`, m);

            

            try {

                // client.sendFile: (chatId, fileUrl/path, filename, caption, quoted, options)

                await client.sendFile(m.chat, downloadLink, `${res.data.anime}.mp4`, `*Berhasil Mengirim Episode!*`, m);

                client.sendReact(m.chat, "✅", m.key);

            } catch (fileError) {

                console.log("Gagal mengirim file langsung:", fileError);

                await client.reply(m.chat, `❌ Gagal mengirim file langsung (server download mungkin memblokir).\nLink: ${downloadLink}`, m);

                client.sendReact(m.chat, "⚠️", m.key);

            }

        }

        

        return client.sendReact(m.chat, "✅", m.key);

      }

      

      // ==========================

      // Mode 3: SEARCH (Nama Anime) - Menggunakan List Message

      // ==========================

      if (isNaN(text)) {

          const res = await search(text);

          if (res.code !== 200 || res.data.length === 0) {

              client.sendReact(m.chat, "❌", m.key);

              return client.reply(m.chat, `❌ Anime "${text}" tidak ditemukan!`, m);

          }

          

          // --- Persiapan List Message ---

          let rows = res.data.map(v => ({

              title: v.title,

              description: `Status: ${v.status}`,

              id: `${isPrefix}otakudesu ${v.link}`

          }));

          const listParams = {

              title: "PILIH ANIME",

              sections: [{

                  title: "Hasil Pencarian",

                  rows: rows

              }]

          };

          const buttons = [{

              name: "single_select",

              buttonParamsJson: JSON.stringify(listParams),

          }];

          

          let caption = `*OTAKUDESU — HASIL PENCARIAN*\n\nQuery: ${text}\n\n*Total ${res.data.length} Hasil*\nSilakan klik tombol di bawah untuk memilih:`;

          

          // --- KIRIM LIST MESSAGE DENGAN client.sendIAMessage ---

          await client.sendIAMessage(

              m.chat, 

              buttons, 

              m, 

              {

                header: 'Hasil Pencarian Otakudesu',

                content: caption,

                footer: footer,

                // media: null 

              }

          );

          // -------------------------------------------------------

          return client.sendReact(m.chat, "✅", m.key);

      }

      // ==========================

      // Mode 4: ONGOING PAGE (Nomor Halaman) - Menggunakan List Message

      // ==========================

      const page = Number(text);

      const ri = await ongoing(page);

      if (ri.code !== 200) {

        client.sendReact(m.chat, "❌", m.key);

        return client.reply(m.chat, "❌ Gagal mengambil ongoing!", m);

      }

      let caption = `*OTAKUDESU — ONGOING ANIME*\n\nHalaman: ${page}\n\n`;

      

      // --- Persiapan List Message ---

      let rows = ri.data.map(v => ({

            title: v.title,

            description: `Rilis: ${v.rilis}`,

            id: `${isPrefix}otakudesu ${v.link}` // Link detail anime

        }));

        

      // Tambahkan tombol Next sebagai baris terpisah

      rows.push({

           title: "Next ▶️",

           description: `Lanjut ke Halaman ${page + 1}`,

           id: `${isPrefix}otakudesu ${page + 1}`

      });

      const listParams = {

          title: "PILIH ANIME",

          sections: [{

              title: "Daftar Anime Ongoing",

              rows: rows

          }]

      };

      const buttons = [{

          name: "single_select",

          buttonParamsJson: JSON.stringify(listParams),

      }];

      let content = `${caption}\n*Silakan pilih anime atau Next untuk halaman selanjutnya.*`;

      

      // --- KIRIM LIST MESSAGE DENGAN client.sendIAMessage ---

      await client.sendIAMessage(

        m.chat,

        buttons,

        m,

        {

            header: 'Ongoing Anime Otakudesu',

            content: content,

            footer: footer,

            // media: null 

        }

      );

      // -------------------------------------------------------

      client.sendReact(m.chat, "✅", m.key);

    } catch (e) {

      console.log(e);

      client.sendReact(m.chat, "❌", m.key);

      client.reply(m.chat, "❌ Terjadi kesalahan saat memproses.", m);

    }

  },

  error: false,

  limit: true,

  cooldown: 3,

};

// ==========================

// SCRAPER FUNCTIONS

// ==========================

// SCRAPER: SEARCH

async function search(query) {

    try {

        const res = await axios.get(`https://otakudesu.cloud/?s=${encodeURIComponent(query)}&post_type=anime`);

        const $ = load(res.data);

        

        let data = [];

        

        $(".chivsrc li").each((i, e) => {

            const titleElement = $(e).find("h2 > a");

            const detailText = $(e).find("div").text().trim().split('\n').filter(t => t.trim() !== '');

            

            const link = titleElement.attr("href");

            const title = titleElement.text().trim();

            

            let status = detailText.find(t => t.includes('Status:')) || '';

            status = status.replace('Status:', '').trim();

            if (title && link) {

                data.push({ title, status, link });

            }

        });

        return { code: 200, data };

    } catch (e) {

        return { code: 404, message: e };

    }

}

// SCRAPER: DETAIL

async function detail(link) { 

    try { 

        const res = await axios.get(link); 

        const $ = load(res.data);

        const thumb = $(".fotoanime img").attr("src");

        let info = [];

        $(".infozingle p").each((i, e) => info.push($(e).text()));

        let text = info.join("\n");

        let links = [];

        $(".episodelist li a").each((i, e) => {

            links.push({ name: $(e).text().trim(), link: $(e).attr("href") });

        });

        

        links = links.filter(v => !v.name.toLowerCase().includes('lihat semua episode'));

        return { code: 200, data: { thumb, text, links } };

    } catch (e) { 

        return { code: 404, message: e }; 

    } 

}

// SCRAPER: EPISODE LINK

async function link(url) { 

    try { 

        const res = await axios.get(url); 

        const $ = load(res.data);

        let anime = $(".venz > h1").text() || $(".subheading h2").first().text();

        let list = [];

        $(".download ul li").each((i, e) => {

            let reso = $(e).find("strong").text().trim() + " | Size " + $(e).find("i").text().trim();

            let link = "";

            $(e).find("a").each((_, el) => {

                link += `${$(el).text().trim()}: ${$(el).attr("href")}\n`;

            });

            list.push({ reso, link: link.trim() });

        });

        return { code: 200, data: { anime, list } };

    } catch (e) { 

        return { code: 404, message: e }; 

    } 

}

// SCRAPER: ONGOING

async function ongoing(page = 1) { 

    try { 

        const res = await axios.get(`https://otakudesu.cloud/ongoing-anime/page/${page}/`); 

        const $ = load(res.data);

        let data = [];

        $(".detpost").each((i, e) => {

            let title = $(e).find(".jdlflm").text().trim() + " " + $(e).find(".epz").text().trim();

            let rilis = $(e).find(".epztipe").text().trim() + " " + $(e).find(".newnime").text().trim();

            let link = $(e).find(".thumb > a").attr("href");

            data.push({ title, rilis, link });

        });

        return { code: 200, data };

    } catch (e) { 

        return { code: 404, message: e }; 

    } 

}

