import axios from "axios";

export const run = {

   usage: ['pin', 'pinterest'],

   use: 'url <quality>',

   category: 'downloader',

   cooldown: 5,

   limit: true,

   async: async (m, { client, text, isPrefix, command, Utils }) => {

      try {

         const input = text?.trim();

         if (!input)

            return client.reply(

               m.chat,

               Utils.example(isPrefix, command, 'https://pin.it/xxx original\n\nQuality: 236p, 564p, original'),

               m

            );

         const parts = input.split(/\s+/);

         const pinUrl = parts[0];

         const quality = parts[1] || "original";

         const validQuality = ["236p", "564p", "original"];

         if (!validQuality.includes(quality))

            return client.reply(

               m.chat,

               Utils.texted('bold', `❌ Kualitas tidak ditemukan!\nTersedia: ${validQuality.join(', ')}`),

               m

            );

         // =======================

         //  FIXED: UNIVERSAL PINTEREST REGEX

         // =======================

         const pinRegex = /^(https?:\/\/)?(www\.)?(pin\.it|([a-z]+\.)?pinterest\.com)\//i;

         if (!pinRegex.test(pinUrl))

            return client.reply(m.chat, Utils.texted('bold', "❌ URL Pinterest tidak valid!"), m);

         client.sendReact(m.chat, '⏳', m.key);

         const apiUrl =

            `https://restapi.rizk.my.id/pinterest/download?url=${encodeURIComponent(pinUrl)}&apikey=vip`;

         const { data: json } = await axios.get(apiUrl);

         if (!json.status || !Array.isArray(json.result))

            throw new Error("Gagal mengambil data Pinterest.");

         const chosen = json.result.find(a => a.quality === quality);

         if (!chosen)

            throw new Error(`Kualitas ${quality} tidak tersedia.`);

         await client.sendMessage(m.chat, {

            image: { url: chosen.url },

            caption:

`🖼️ *Pinterest Downloader*

📌 Quality: ${chosen.quality}

📦 Size: ${chosen.formattedSize}`

         }, { quoted: m });

         client.sendReact(m.chat, '✅', m.key);

      } catch (e) {

         console.error("Pinterest Error:", e);

         client.sendReact(m.chat, '❌', m.key);

         client.reply(

            m.chat,

            Utils.texted('bold', `🚨 Terjadi kesalahan: ${e.message}`),

            m

         );

      }

   },

   error: false,

};