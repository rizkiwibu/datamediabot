import axios from 'axios'

export const run = {
   usage: ['play'],
   use: 'text',
   category: 'downloader',
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      Utils
   }) => {
      try {
         if (!text) return client.reply(m.chat, Utils.example(isPrefix, command, 'Alan Walker - Alone'), m)
         
         // Memberikan reaksi 'jam' untuk indikator loading
         client.sendReact(m.chat, '🕒', m.key) 
         
         const { data } = await axios.get(`https://api.nekolabs.web.id/downloader/youtube/play/v1?q=${encodeURIComponent(text)}`);

         if (!data.success) {
             client.sendReact(m.chat, '', m.key) // Hapus loading
             return client.reply(m.chat, Utils.texted('bold', `❌ Gagal mengambil data, coba judul lain.`), m)
         }

         const result = data.result;
         const { title, channel, cover } = result.metadata;
         
         // 🔴 PERBAIKAN: Menggunakan client.sendMessage dengan struktur payload yang benar
         await client.sendMessage(m.chat, {
             // 1. Audio dikirim via URL
             audio: { url: result.downloadUrl }, 
             mimetype: "audio/mpeg",
             fileName: `${title}.mp3`,
             // 2. Hapus ptt: true agar terkirim sebagai file MP3/musik
             
             // 3. contextInfo (externalAdReply) DIPINDAHKAN KE DALAM payload media
             contextInfo: {
                 externalAdReply: {
                     title,
                     body: channel,
                     thumbnailUrl: cover,
                     mediaType: 1,
                     renderLargerThumbnail: true,
                 },
             },
         }, {
             // 4. Quoted message tetap di objek opsi kedua
             quoted: m,
         });

         // 5. Hapus reaksi 'jam' setelah berhasil
         client.sendReact(m.chat, '', m.key)

      } catch (e) {
         console.error("Play Error:", e);
         // Hapus reaksi 'jam' jika terjadi error
         client.sendReact(m.chat, '', m.key)
         client.reply(m.chat, Utils.texted('bold', `🚩 Terjadi kesalahan: Gagal memproses permintaan play.`), m)
      }
   },
   error: false,
   limit: true,
   cooldown: 3
}
