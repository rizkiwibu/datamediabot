import axios from "axios";
import https from "https";
import FormData from "form-data"; 

// 💡 FIX 1: Mengabaikan error sertifikat SSL/TLS
const httpsAgent = new https.Agent({ rejectUnauthorized: false }); 

// --- FUNGSI HELPER INTERNAL ---
function kyahhh(k) {
  return k.replace(/[\p{Emoji_Presentation}\p{Emoji}\uFE0F]/gu, "").trim().replace(/\s+/g, "_");
}

function obj(x) {
  if (Array.isArray(x)) return x.map(v => obj(v));
  if (x && typeof x === "object") {
    const out = {};
    for (const key in x) out[kyahhh(key)] = obj(x[key]);
    return out;
  }
  return x;
}

async function getNonce(url) {
  const html = (await axios.get(url, { httpsAgent, timeout: 10000 })).data;
  const m = html.match(/var\s+terabox_ajax\s*=\s*(\{[\s\S]*?\});/m);
  if (!m) return null;
  try {
    return JSON.parse(m[1]).nonce ?? null;
  } catch {
    return null;
  }
}

async function teraboxDL(link, opt = {}) {
  const parse = opt.parse_result ?? false;
  const nonce = await getNonce("https://teradownloadr.com/");
  if (!nonce) throw new Error("Gagal mendapatkan token keamanan (nonce).");
    
  const form = new FormData();
  form.append("action", "terabox_fetch");
  form.append("url", link);
  form.append("nonce", nonce);
  
  const headers = form.getHeaders ? form.getHeaders() : { "Content-Type": "multipart/form-data" };
    
  // 🛠️ FIX 2: LOGIKA RETRY (Coba Ulang)
  const MAX_RETRIES = 3;
  let responseData = null;
  let lastError = null;

  for (let i = 0; i < MAX_RETRIES; i++) {
    try {
      const response = await axios.post(
        "https://teradownloadr.com/wp-admin/admin-ajax.php",
        form,
        { headers, httpsAgent, timeout: 20000 } // Menambahkan timeout 20 detik
      );
      responseData = response.data;
      break; // Berhasil, keluar dari loop
    } catch (e) {
      lastError = e;
      if (i < MAX_RETRIES - 1) {
        // Coba lagi setelah jeda 1.5 detik jika bukan percobaan terakhir
        await new Promise(resolve => setTimeout(resolve, 1500)); 
        continue;
      }
      // Semua percobaan gagal, lempar error terakhir
      throw lastError; 
    }
  }

  // Pengecekan data setelah loop
  if (!responseData) {
      throw new Error("Gagal mengambil data setelah 3 kali percobaan.");
  }
    
  return parse ? obj(responseData.data) : responseData.data;
}
// --- AKHIR FUNGSI HELPER INTERNAL ---


// --- PLUGIN BOT UTAMA ---
export const run = {
   usage: ['terabox', 'tbdl'],
   use: 'link',
   category: 'downloader',
   cooldown: 15,
   limit: true,
   async: async (m, {
      client,
      text, 
      isPrefix,
      command,
      Utils
   }) => {
      try {
         const link = text?.trim();
         
         if (!link || !link.includes('terabox')) {
            return client.reply(m.chat, Utils.example(isPrefix, command, 'https://www.terabox.com/s/xxxxx'), m);
         }
         
         client.sendReact(m.chat, '🕒', m.key);

         const result = await teraboxDL(link, { parse_result: true });
         
         if (!result || result.status !== "success" || !result.url) {
            client.sendReact(m.chat, '❌', m.key);
            const msg = result?.message || "Gagal mengambil data dari Terabox. Mungkin link salah, file terlalu besar, atau API sedang *down*.";
            return client.reply(m.chat, Utils.texted('bold', `❌ ${msg}`), m);
         }
         
         const { filename, size, url } = result;

         let responseMsg = `
☁️ *TERABOX DOWNLOADER*

*Nama:* ${filename || 'N/A'}
*Ukuran:* ${size || 'N/A'}
*Status:* Berhasil

🔗 *Link Download Langsung:*
${url}
         `.trim();

         client.reply(m.chat, responseMsg, m);
         
         client.sendReact(m.chat, '✅', m.key);

      } catch (e) {
         console.error("Terabox Error:", e);
         client.sendReact(m.chat, '❌', m.key);
         let errorMessage = e.message.includes('nonce') ? 'Gagal mendapatkan token keamanan. Coba lagi.' : e.message;
         errorMessage = errorMessage.includes('404') ? 'Link Terabox tidak ditemukan atau sudah kadaluarsa.' : errorMessage;
         
         return client.reply(m.chat, Utils.texted('bold', `❌ Terjadi kesalahan: ${errorMessage}`), m);
      }
   },
   error: false,
   limit: true
}
