import axios from "axios";

import * as cheerio from "cheerio";

async function ttdown(url) {

  try {

    if (!url.includes("tiktok.com")) throw new Error("URL tidak valid.");

    // GET token + session

    const home = await axios.get("https://musicaldown.com/en", {

      headers: {

        "user-agent": "Mozilla/5.0",

      },

    });

    const cookies = home.headers["set-cookie"]?.join("; ") || "";

    const $ = cheerio.load(home.data);

    const payload = {};

    $("#submit-form input").each((i, el) => {

      const name = $(el).attr("name");

      const value = $(el).attr("value");

      if (name) payload[name] = value || "";

    });

    const field = Object.keys(payload).find((k) => payload[k] === "");

    if (field) payload[field] = url;

    const post = await axios.post(

      "https://musicaldown.com/download",

      new URLSearchParams(payload).toString(),

      {

        headers: {

          cookie: cookies,

          origin: "https://musicaldown.com",

          referer: "https://musicaldown.com/",

          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",

          "user-agent": "Mozilla/5.0",

        },

      }

    );

    const $$ = cheerio.load(post.data);

    const header = $$(".video-header").attr("style");

    const cover = header?.match(/url\((.*?)\)/)?.[1] || null;

    const downloads = [];

    $$("a.download").each((_, el) => {

      const x = $$(el);

      downloads.push({

        type: x.data("event")?.replace("_download_click", "") || "",

        label: x.text().trim(),

        url: x.attr("href"),

      });

    });

    return {

      title: $$(".video-desc").text().trim(),

      author: {

        username: $$(".video-author b").text().trim(),

        avatar: $$(".img-area img").attr("src"),

      },

      cover,

      downloads,

    };

  } catch (err) {

    throw new Error("Scraper Error: " + err.message);

  }

}

// =========================================================

// ===============  PLUGIN WHATSAPP  ========================

// =========================================================

export const run = {

  usage: ["tt", "tiktok"],

  use: "url",

  category: "downloader",

  cooldown: 5,

  limit: true,

  async: async (m, { client, text, isPrefix, command, Utils }) => {

    try {

      const input = text?.trim();

      if (!input)

        return client.reply(

          m.chat,

          Utils.example(isPrefix, command, "https://vt.tiktok.com/xxxx"),

          m

        );

      client.sendReact(m.chat, "⏳", m.key);

      const data = await ttdown(input);

      if (!data.downloads || !data.downloads.length)

        return client.reply(m.chat, "❌ Tidak ada link download ditemukan.", m);

      // Cari video no watermark

      const video =

        data.downloads.find((x) =>

          x.label.toLowerCase().includes("no watermark")

        ) || data.downloads[0];

      // Cari audio

      const audio = data.downloads.find((x) =>

        x.label.toLowerCase().includes("audio")

      );

      let caption = `🎬 *TikTok Downloader*\n`;

      caption += `👤 @${data.author.username}\n`;

      caption += `📝 ${data.title}\n\n`;

      // Kirim video

      await client.sendMessage(

        m.chat,

        {

          video: { url: video.url },

          caption,

        },

        { quoted: m }

      );

      // Kirim audio jika ada

      if (audio) {

        await client.sendMessage(

          m.chat,

          {

            audio: { url: audio.url },

            mimetype: "audio/mpeg",

            fileName: "tiktok.mp3",

          },

          { quoted: m }

        );

      }

      client.sendReact(m.chat, "✅", m.key);

    } catch (err) {

      console.log(err);

      client.sendReact(m.chat, "❌", m.key);

      client.reply(m.chat, `❌ Error: ${err.message}`, m);

    }

  },

  error: false,

};