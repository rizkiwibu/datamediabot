import axios from 'axios'

export const run = {
   // Mengubah command, usage, dan category sesuai format baru
   usage: ['ytmp4', 'ytv'],
   use: 'url <quality>', // Contoh penggunaan yang lebih ringkas
   category: 'downloader',
   cooldown: 5,
   limit: true,
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      Utils
   }) => {
      try {
         const input = text?.trim();
         
         // 1. Pengecekan input
         if (!input)
            return client.reply(m.chat, Utils.example(isPrefix, command, 'https://youtu.be/xxxx 720\n\nKualitas tersedia: 144, 240, 360, 480, 720, 1080'), m)

         const parts = input.split(/\s+/); // Split menggunakan regex untuk menangani multiple spaces
         
         if (parts.length < 2)
            return client.reply(m.chat, Utils.texted('bold', `Format salah!\nGunakan contoh: ${isPrefix}${command} https://youtu.be/xxxx 720`), m);

         const url = parts[0];
         const format = parts[1];
         const validFormats = ["144", "240", "360", "480", "720", "1080"];

         if (!validFormats.includes(format))
            return client.reply(m.chat, Utils.texted('bold', `❌ Kualitas tidak valid!\nTersedia: ${validFormats.join(", ")}`), m);

         const youtubeRegex =
            /^(https?:\/\/)?((www|m)\.)?(youtube(-nocookie)?\.com\/(watch\?v=|shorts\/|live\/)|youtu\.be\/)[\w\-]+(\S+)?$/i;
         if (!youtubeRegex.test(url)) return client.reply(m.chat, Utils.texted('bold', "❌ URL YouTube tidak valid!"), m);

         // 2. Memberikan reaksi 'jam' untuk indikator loading
         client.sendReact(m.chat, '🕒', m.key)

         // 3. Mengganti fetch dengan axios
         const apiUrl = `https://api.nekolabs.web.id/downloader/youtube/v1?url=${encodeURIComponent(
            url
         )}&format=${encodeURIComponent(format)}`;

         const { data: json } = await axios.get(apiUrl);

         if (!json.success || !json.result?.downloadUrl)
            throw new Error("Gagal memproses video. Coba lagi nanti.");

         if (json.result.type !== "video") {
            client.sendReact(m.chat, '', m.key)
            return client.reply(m.chat, Utils.texted('bold', "❗ Ini sepertinya konten audio saja. Gunakan .play atau .ytmp3"), m);
         }

         const { title, downloadUrl, quality } = json.result;

         // 4. Mengirim video menggunakan client.sendMessage
         await client.sendMessage(m.chat, {
            // Video dikirim via URL
            video: { url: downloadUrl },
            caption: `🎬 *${title}*\n📺 Kualitas: ${quality}p`,
         }, {
            quoted: m,
         });

         // 5. Mengganti reaksi loading dengan '✅'
         client.sendReact(m.chat, '✅', m.key)

      } catch (e) {
         console.error("Ytmp4 Error:", e);
         // 6. Mengganti reaksi loading dengan '❌'
         client.sendReact(m.chat, '❌', m.key)
         client.reply(m.chat, Utils.texted('bold', `🚩 Terjadi kesalahan: ${e.message}`), m)
      }
   },
   error: false,
   // Semua properti lain yang tidak ada di struktur baru dihilangkan (hidden, failed, wait, dll.)
}
