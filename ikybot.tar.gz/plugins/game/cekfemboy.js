export const run = {

    usage: ["cekfemboy", "femboy"],

    category: "fun",

    

    async: async (m, { client, text }) => {

        if (!text) return m.reply("Masukkan nama!\nContoh: *cekfemboy reza*");

        const percent = Math.floor(Math.random() * 101);

        let desc = "";

        let gif = "";

        if (percent < 20) {

            desc = "Cowok banget! 😎";

            gif = "https://raw.githubusercontent.com/rizkiwibu/datamediabot/refs/heads/main/normal.webp";

        } else if (percent < 40) {

            desc = "Ada aura lembutnya dikit~ 🌸";

            gif = "https://raw.githubusercontent.com/rizkiwibu/datamediabot/refs/heads/main/dibwh40.webp";

        } else if (percent < 60) {

            desc = "Lumayan femboy 😘";

            gif = "https://raw.githubusercontent.com/rizkiwibu/datamediabot/refs/heads/main/dibwh60.webp";

        } else if (percent < 80) {

            desc = "Femboy sejati 💅✨";

            gif = "https://raw.githubusercontent.com/rizkiwibu/datamediabot/refs/heads/main/dibwh80.webp";

        } else {

            desc = "FEMBOY DEWA 🔥💖";

            gif = "https://raw.githubusercontent.com/rizkiwibu/datamediabot/refs/heads/main/femboyyyy.webp";

        }

        const caption = `${text}, kamu ${percent}% femboy! ${desc}`;

        await client.sendSticker(m.chat, gif, m, {

            packname: "Cek Femboy",

            author: "© Bot"

        });

        await m.reply(caption);

    },

    error: false,

    limit: false,

};