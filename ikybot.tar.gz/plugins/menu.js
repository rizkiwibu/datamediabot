import { Version } from '@neoxr/wb'

import fs from 'node:fs'

import os from 'node:os'

const menuAudio = 'https://raw.githubusercontent.com/rizkiwibu/datamediabot/refs/heads/main/menu.m4a'

export const run = {

  usage: ['menu', 'help', 'command'],

  async: async (m, {

    client,

    text,

    isPrefix,

    command,

    setting,

    system,

    plugins,

    Config,

    Utils

  }) => {

    try {

      const local_size = fs.existsSync('./' + Config.database + '.json')

        ? await Utils.formatSize(fs.statSync('./' + Config.database + '.json').size)

        : ''

      const pkg = JSON.parse(fs.readFileSync('./package.json', 'utf-8'))

      const library = pkg.dependencies?.baileys

        ? 'Baileys'

        : pkg.name || 'Unknown'

      // ================== RAM ==================

      const totalRam = os.totalmem()

      const freeRam = os.freemem()

      const usedRam = totalRam - freeRam

      const ram = `${Utils.formatSize(usedRam)} / ${Utils.formatSize(totalRam)}`

      // ================== CPU ==================

      const cpu = os.cpus()?.[0]?.model || 'Unknown CPU'

     // ================== UPTIME (FIX: TANPA Utils.runtime) ==================
const seconds = process.uptime()
const days = Math.floor(seconds / (3600 * 24))
const hours = Math.floor((seconds % (3600 * 24)) / 3600)
const minutes = Math.floor((seconds % 3600) / 60)
const secs = Math.floor(seconds % 60)

const uptime = `${days}d ${hours}h ${minutes}m ${secs}s`

      const message = setting.msg

        .replace(/\+tag/g, `@${m.sender.replace(/@.+/g, '')}`)

        .replace(/\+name/g, m.pushName || 'User')

        .replace(/\+greeting/g, Utils.greeting())

        .replace(

          /\+db/g,

          (system.name === 'Local'

            ? `Local (${local_size})`

            : system.name)

        )

        .replace(/\+module/g, Version)

        .replace(/\+library/g, library)

        .replace(/\+ram/g, ram)

        .replace(/\+cpu/g, cpu)

        .replace(/\+uptime/g, uptime)

        .replace(/\^/g, '')

        .replace(/~/g, '')

      const style = setting.style

      // ================= STYLE 1 =================

      if (style === 1) {

        let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)

        let cmd = Object.fromEntries(filter)

        let category = []

        for (let name in cmd) {

          let obj = cmd[name].run

          if (!cmd) continue

          if (!obj.category || setting.hidden.includes(obj.category)) continue

          if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)

          else {

            category[obj.category] = []

            category[obj.category].push(obj)

          }

        }

        const keys = Object.keys(category).sort()

        let print = message

        print += '\n' + String.fromCharCode(8206).repeat(4001)

        for (let k of keys) {

          print += '\n\n> *' + k.toUpperCase().split('').join(' ') + '*\n\n'

          let cmdList = Object.entries(plugins).filter(

            ([_, v]) => v.run.usage && v.run.category == k.toLowerCase()

          )

          let usage = Object.keys(Object.fromEntries(cmdList))

          if (usage.length === 0) continue

          let commands = []

          cmdList.map(([_, v]) => {

            switch (v.run.usage.constructor.name) {

              case 'Array':

                v.run.usage.map(x =>

                  commands.push({

                    usage: x,

                    use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                  })

                )

                break

              case 'String':

                commands.push({

                  usage: v.run.usage,

                  use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                })

            }

          })

          print += commands

            .sort((a, b) => a.usage.localeCompare(b.usage))

            .map(v => `  - ${isPrefix + v.usage} ${v.use}`)

            .join('\n')

        }

        client.sendMessageModify(

          m.chat,

          Utils.Styles(print) + '\n\n' + global.footer,

          m,

          {

            ads: false,

            largeThumb: true,

            thumbnail: Utils.isUrl(setting.cover)

              ? setting.cover

              : Buffer.from(setting.cover, 'base64'),

            url: setting.link

          }

        )

      // ================= STYLE 2 =================

      } else if (style === 2) {

        let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)

        let cmd = Object.fromEntries(filter)

        let category = []

        for (let name in cmd) {

          let obj = cmd[name].run

          if (!cmd) continue

          if (!obj.category || setting.hidden.includes(obj.category)) continue

          if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)

          else {

            category[obj.category] = []

            category[obj.category].push(obj)

          }

        }

        const keys = Object.keys(category).sort()

        let print = message

        print += '\n' + String.fromCharCode(8206).repeat(4001)

        for (let k of keys) {

          print += '\n\n- *' + k.toUpperCase().split('').join(' ') + '*\n\n'

          let cmdList = Object.entries(plugins).filter(

            ([_, v]) => v.run.usage && v.run.category == k.toLowerCase()

          )

          let usage = Object.keys(Object.fromEntries(cmdList))

          if (usage.length === 0) continue

          let commands = []

          cmdList.map(([_, v]) => {

            switch (v.run.usage.constructor.name) {

              case 'Array':

                v.run.usage.map(x =>

                  commands.push({

                    usage: x,

                    use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                  })

                )

                break

              case 'String':

                commands.push({

                  usage: v.run.usage,

                  use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                })

            }

          })

          print += commands

            .sort((a, b) => a.usage.localeCompare(b.usage))

            .map(v => `  - ${isPrefix + v.usage} ${v.use}`)

            .join('\n')

        }

        client.sendMessageModify(

          m.chat,

          Utils.Styles(print) + '\n\n' + global.footer,

          m,

          {

            ads: false,

            largeThumb: true,

            thumbnail: Utils.isUrl(setting.cover)

              ? setting.cover

              : Buffer.from(setting.cover, 'base64'),

            url: setting.link

          }

        )

      // ================= STYLE 3 =================

      } else if (style === 3) {

        let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)

        let cmd = Object.fromEntries(filter)

        let category = []

        for (let name in cmd) {

          let obj = cmd[name].run

          if (!cmd) continue

          if (!obj.category || setting.hidden.includes(obj.category)) continue

          if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)

          else {

            category[obj.category] = []

            category[obj.category].push(obj)

          }

        }

        const keys = Object.keys(category).sort()

        let print = message

        print += '\n' + String.fromCharCode(8206).repeat(4001)

        for (let k of keys) {

          print += '\n\n- *' + k.toUpperCase().split('').join(' ') + '*\n\n'

          let cmdList = Object.entries(plugins).filter(

            ([_, v]) => v.run.usage && v.run.category == k.toLowerCase()

          )

          let usage = Object.keys(Object.fromEntries(cmdList))

          if (usage.length === 0) continue

          let commands = []

          cmdList.map(([_, v]) => {

            switch (v.run.usage.constructor.name) {

              case 'Array':

                v.run.usage.map(x =>

                  commands.push({

                    usage: x,

                    use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                  })

                )

                break

              case 'String':

                commands.push({

                  usage: v.run.usage,

                  use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                })

            }

          })

          print += commands

            .sort((a, b) => a.usage.localeCompare(b.usage))

            .map(v => `  - ${isPrefix + v.usage} ${v.use}`)

            .join('\n')

        }

        client.sendMessageModify(

          m.chat,

          print + '\n\n' + global.footer,

          m,

          {

            ads: false,

            largeThumb: true,

            thumbnail: Utils.isUrl(setting.cover)

              ? setting.cover

              : Buffer.from(setting.cover, 'base64'),

            url: setting.link

          }

        )

      // ================= STYLE 4 =================

      } else if (style === 4) {

        if (text) {

          let cmdList = Object.entries(plugins).filter(

            ([_, v]) =>

              v.run.usage &&

              v.run.category == text.trim().toLowerCase() &&

              !setting.hidden.includes(v.run.category.toLowerCase())

          )

          let usage = Object.keys(Object.fromEntries(cmdList))

          if (usage.length === 0) return

          let commands = []

          cmdList.map(([_, v]) => {

            switch (v.run.usage.constructor.name) {

              case 'Array':

                v.run.usage.map(x =>

                  commands.push({

                    usage: x,

                    use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                  })

                )

                break

              case 'String':

                commands.push({

                  usage: v.run.usage,

                  use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                })

            }

          })

          let print = commands

            .sort((a, b) => a.usage.localeCompare(b.usage))

            .map(v => `- ${isPrefix + v.usage} ${v.use}`)

            .join('\n')

          m.reply(print)

        } else {

          let print = message

          print += '\n' + String.fromCharCode(8206).repeat(4001) + '\n'

          let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)

          let cmd = Object.fromEntries(filter)

          let category = []

          for (let name in cmd) {

            let obj = cmd[name].run

            if (!cmd) continue

            if (!obj.category || setting.hidden.includes(obj.category)) continue

            if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)

            else {

              category[obj.category] = []

              category[obj.category].push(obj)

            }

          }

          const keys = Object.keys(category).sort()

          print += keys

            .sort((a, b) => a.localeCompare(b))

            .map(v => `- ${isPrefix + command} ${v}`)

            .join('\n')

          client.sendMessageModify(

            m.chat,

            print + '\n\n' + global.footer,

            m,

            {

              ads: false,

              largeThumb: true,

              thumbnail: Utils.isUrl(setting.cover)

                ? setting.cover

                : Buffer.from(setting.cover, 'base64'),

              url: setting.link

            }

          )

        }

      // ================= STYLE 5 =================

      } else if (style === 5) {

        if (text) {

          let cmdList = Object.entries(plugins).filter(

            ([_, v]) =>

              v.run.usage &&

              v.run.category == text.trim().toLowerCase() &&

              !setting.hidden.includes(v.run.category.toLowerCase())

          )

          let usage = Object.keys(Object.fromEntries(cmdList))

          if (usage.length === 0) return

          let commands = []

          cmdList.map(([_, v]) => {

            switch (v.run.usage.constructor.name) {

              case 'Array':

                v.run.usage.map(x =>

                  commands.push({

                    usage: x,

                    use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                  })

                )

                break

              case 'String':

                commands.push({

                  usage: v.run.usage,

                  use: v.run.use ? Utils.texted('bold', v.run.use) : ''

                })

            }

          })

          let print = commands

            .sort((a, b) => a.usage.localeCompare(b.usage))

            .map(v => `- ${isPrefix + v.usage} ${v.use}`)

            .join('\n')

          m.reply(Utils.Styles(print))

        } else {

          let print = message

          let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)

          let cmd = Object.fromEntries(filter)

          let category = []

          for (let name in cmd) {

            let obj = cmd[name].run

            if (!cmd) continue

            if (!obj.category || setting.hidden.includes(obj.category)) continue

            if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)

            else {

              category[obj.category] = []

              category[obj.category].push(obj)

            }

          }

          const keys = Object.keys(category).sort()

          let sections = []

          const label = { highlight_label: 'Many Used' }

          keys

            .sort((a, b) => a.localeCompare(b))

            .map(v =>

              sections.push({

                ...(/download|conver|util/.test(v) ? label : {}),

                rows: [{

                  title: Utils.ucword(v),

                  description: `There are ${Utils.arrayJoin(

                    Object.entries(plugins)

                      .filter(

                        ([_, x]) =>

                          x.run.usage &&

                          x.run.category ==

                          v.trim().toLowerCase() &&

                          !setting.hidden.includes(

                            x.run.category.toLowerCase()

                          )

                      )

                      .map(([_, x]) => x.run.usage)

                  ).length} commands`,

                  id: `${isPrefix + command} ${v}`

                }]

              })

            )

          const buttons = [{

            name: 'single_select',

            buttonParamsJson: JSON.stringify({

              title: 'Tap Here!',

              sections

            })

          }]

          client.sendIAMessage(m.chat, buttons, m, {

            header: '',

            content: print,

            footer: global.footer,

            media: Utils.isUrl(setting.cover)

              ? setting.cover

              : Buffer.from(setting.cover, 'base64')

          })

        }

      }

      // =============== AUDIO SETELAH MENU ===============

      if (command === 'menu') {

        setTimeout(async () => {

          try {

            await client.sendMessage(

              m.chat,

              {

                audio: { url: menuAudio },

                mimetype: 'audio/mpeg',

                ptt: true

              },

              { quoted: m }

            )

          } catch (e) { }

        }, 1200)

      }

    } catch (e) {

      client.reply(m.chat, Utils.jsonFormat(e), m)

    }

  },

  error: false

}