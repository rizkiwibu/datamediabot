export const run = {
   usage: ['owner'],
   category: 'miscs',
   async: async (m, {
      client,
      Config
   }) => {
      client.sendContact(m.chat, [{
         name: Config.owner_name,
         number: Config.owner,
         about: 'Owner & Creator'
      }], m, {
         org: 'Neoxr Network',
         website: 'https://api.rizk.my.id',
         email: 'contact@rizk.my.id'
      })
   },
   error: false
}