export const run = {

  usage: ['addlimit', '+limit'],

  use: 'reply | mention | number | self',

  category: 'owner',

  async: async (m, { client, args, text, isPrefix, command, Utils }) => {

    try {

      let userDB = global.db.users

      // jumlah limit

      let amount = parseInt(args[0])

      if (isNaN(amount)) amount = 10

      // ================= REPLY =================

      if (m.quoted) {

        if (m.quoted.isBot)

          return client.reply(m.chat, Utils.texted('bold', `🚩 Cannot add limit to bot.`), m)

        let jid = client.decodeJid(m.quoted.sender)

        let users = userDB.find(v => v.jid === jid)

        if (!users)

          return client.reply(m.chat, Utils.texted('bold', `🚩 User not found in database.`), m)

        users.limit += amount

        return client.reply(

          m.chat,

          Utils.texted('bold', `✅ Successfully added ${amount} limit to @${jid.replace(/@.+/, '')}\nTotal limit: ${users.limit}`),

          m

        )

      }

      // ================= MENTION =================

      else if (m.mentionedJid.length !== 0) {

        let jid = client.decodeJid(m.mentionedJid[0])

        let users = userDB.find(v => v.jid === jid)

        if (!users)

          return client.reply(m.chat, Utils.texted('bold', `🚩 User not found in database.`), m)

        users.limit += amount

        return client.reply(

          m.chat,

          Utils.texted('bold', `✅ Successfully added ${amount} limit to @${jid.replace(/@.+/, '')}\nTotal limit: ${users.limit}`),

          m

        )

      }

      // ================= NUMBER | AMOUNT =================

      else if (text && /\|/.test(text)) {

        let [number, amt] = text.split`|`

        let p = (await client.onWhatsApp(

          String(number).startsWith('0')

            ? '62' + String(number).slice(1)

            : number.startsWith('+')

              ? number.match(/\d+/g).join('')

              : number

        ))[0] || {}

        if (!p.exists)

          return client.reply(m.chat, Utils.texted('bold', '🚩 Number not registered on WhatsApp.'), m)

        let jid = client.decodeJid(p.jid)

        let users = userDB.find(v => v.jid === jid)

        if (!users)

          return client.reply(m.chat, Utils.texted('bold', `🚩 User not found in database.`), m)

        let add = parseInt(amt)

        if (isNaN(add)) add = amount

        users.limit += add

        return client.reply(

          m.chat,

          Utils.texted('bold', `✅ Successfully added ${add} limit to @${jid.replace(/@.+/, '')}\nTotal limit: ${users.limit}`),

          m

        )

      }

      // ================= SELF (tanpa mention) =================

      else {

        let jid = client.decodeJid(m.sender)

        let users = userDB.find(v => v.jid === jid)

        if (!users)

          return client.reply(m.chat, Utils.texted('bold', `🚩 Your data not found in database.`), m)

        users.limit += amount

        return client.reply(

          m.chat,

          Utils.texted('bold', `✅ Successfully added ${amount} limit to yourself.\nTotal limit: ${users.limit}`),

          m

        )

      }

    } catch (e) {

      console.error(e)

      client.reply(m.chat, Utils.texted('bold', `🚩 Error occurred while adding limit.`), m)

    }

  },

  error: false,

  owner: true

}