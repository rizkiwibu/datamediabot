import axios from "axios";

export const run = {

    usage: ['get'],

    use: 'url',

    category: 'tools',

    cooldown: 5,

    limit: false,

    async: async (m, { client, text, isPrefix, command, Utils }) => {

        try {

            const url = text?.trim();

            if (!url)

                return client.reply(

                    m.chat,

                    Utils.example(isPrefix, command, "https://example.com/data"),

                    m

                );

            client.sendReact(m.chat, '⏳', m.key);

            const res = await axios.get(url, {

                responseType: "arraybuffer"

            });

            const type = res.headers["content-type"];

            const buffer = Buffer.from(res.data);

            // ===== JSON =====

            if (type?.includes("application/json")) {

                const json = JSON.parse(buffer.toString());

                return client.reply(

                    m.chat,

                    "```" + JSON.stringify(json, null, 2) + "```",

                    m

                );

            }

            // ===== IMAGE =====

            if (type?.startsWith("image/")) {

                return client.sendMessage(

                    m.chat,

                    { image: buffer },

                    { quoted: m }

                );

            }

            // ===== VIDEO =====

            if (type?.startsWith("video/")) {

                return client.sendMessage(

                    m.chat,

                    { video: buffer },

                    { quoted: m }

                );

            }

            // ===== AUDIO =====

            if (type?.startsWith("audio/")) {

                return client.sendMessage(

                    m.chat,

                    { audio: buffer, mimetype: type },

                    { quoted: m }

                );

            }

            // ===== TEXT =====

            return client.reply(

                m.chat,

                buffer.toString(),

                m

            );

        } catch (e) {

            client.sendReact(m.chat, '❌', m.key);

            client.reply(m.chat, `❗ Error GET: ${e.message}`, m);

        }

    },

    error: false,

};