import { GoogleGenerativeAI } from "@google/generative-ai";
import fs from "fs";
import path from "path";
import axios from 'axios'; // Diperlukan untuk konsistensi

// --- FUNGSI MANAJEMEN SESI ---
const DB_DIR = "./dbgemini";
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR);

const HISTORY_LIMIT = parseInt(process.env.GEMINI_HISTORY_LIMIT || "50", 10); 

function getSessionPath(jid) {
  return path.join(DB_DIR, `${jid}.json`);
}

function loadSession(jid) {
  const file = getSessionPath(jid);
  if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, "utf-8"));
  return [];
}

function saveSession(jid, data) {
  fs.writeFileSync(getSessionPath(jid), JSON.stringify(data, null, 2));
}

function trimSession(session) {
  if (session.length > HISTORY_LIMIT * 2)
    return session.slice(-HISTORY_LIMIT * 2);
  return session;
}

function toContents(messages) {
  return messages.map((m) => ({
    role: m.role || "user", 
    parts: [{ text: m.content }],
  }));
}
// --- AKHIR FUNGSI MANAJEMEN SESI ---

export const run = {
  usage: ["gemini", "gm", "g"], 
  use: "text | reply_image",
  category: "gemini",
  cooldown: 5,
  limit: true,
  async: async (m, {
    client,
    text,
    isPrefix,
    command,
    Utils,
    Scraper // Helper Scraper sekarang akan digunakan untuk upload
  }) => {
    try {
      if (!process.env.GEMINI_API_KEY)
        return client.reply(m.chat, Utils.texted('bold', "❌ GEMINI_API_KEY belum diatur di .env"), m);

      client.sendReact(m.chat, '🧠', m.key); 

      const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
      const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

      const jid = m.sender || m.key.remoteJid;
      let query = text?.trim() || "";
      const session = loadSession(jid);

      // --- Logika Reset Session ---
      if (/^reset$/i.test(query)) {
        const file = getSessionPath(jid);
        if (fs.existsSync(file)) fs.unlinkSync(file);
        client.sendReact(m.chat, '🧹', m.key);
        return client.reply(m.chat, Utils.texted('bold', "🧹 Session Gemini kamu sudah direset."), m);
      }

      // --- Cek Input Gambar ---
      const potentialMsgs = [];
      if (m.quoted) potentialMsgs.push(m.quoted);
      potentialMsgs.push(m);

      const images = [];
      for (const pm of potentialMsgs) {
        const mime = pm.mimetype || pm.message?.imageMessage?.mimetype || '';
        if (/image\/(jpe?g|png)/.test(mime)) {
          const buf = await client.downloadMedia(pm); 
          
          // 🔴 PERBAIKAN UPLOADER: Menggunakan Scraper.uploadImageV2
          const uploaded = await Scraper.uploadImageV2(buf); 
          const url = uploaded.data.url; // Mengambil URL dari respons Scraper
          images.push(url);
        }
      }

      // --- Logika Input Gambar ---
      if (images.length > 0) {
        client.reply(m.chat, '🧠 Menganalisis gambar kamu...', m); 
        
        const prompt =
          query ||
          "Jelaskan setiap gambar ini secara rinci, sebutkan objek, tindakan, dan konteks.";

        const imageListText = images.map((u, i) => `Gambar ${i + 1}: ${u}`).join("\n");
        const combinedText = `${imageListText}\n\n${prompt}`;

        const contents = [
          { role: "user", parts: [{ text: combinedText }] },
        ];

        const result = await model.generateContent({ contents });
        const replyText = result.response.text();

        session.push({ role: "user", content: prompt });
        session.push({ role: "model", content: replyText });
        saveSession(jid, trimSession(session));
        
        client.sendReact(m.chat, '✅', m.key);
        return client.reply(m.chat, replyText, m);
      }

      // --- Logika Chat Teks Saja ---
      if (!query) return client.reply(m.chat, Utils.texted('bold', "💬 Ketik pesan atau balas gambar."), m);

      const contents = [
        ...toContents(session),
        { role: "user", parts: [{ text: query }] },
      ];

      const result = await model.generateContent({ contents });
      const replyText = result.response.text();

      session.push({ role: "user", content: query });
      session.push({ role: "model", content: replyText });
      saveSession(jid, trimSession(session));

      client.sendReact(m.chat, '✅', m.key);
      await client.reply(m.chat, replyText, m);
      
    } catch (error) {
      console.error("Gemini Error:", error);
      client.sendReact(m.chat, '❌', m.key);
      const emsg = error?.message || String(error);
      return client.reply(m.chat, Utils.texted('bold', `❌ Terjadi kesalahan: ${emsg}`), m);
    }
  },
};
