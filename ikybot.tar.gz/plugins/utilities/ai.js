import axios from "axios";

import { v4 as uuidv4 } from "uuid";

async function aichat(question, { model = "gpt-5-nano" } = {}) {

   const _model = {

      "gpt-4o-mini": "25865",

      "gpt-5-nano": "25871",

      "gemini": "25874",

      "deepseek": "25873",

      "claude": "25875",

      "grok": "25872",

      "meta-ai": "25870",

      "qwen": "25869"

   };

   if (!question) throw new Error("Query kosong");

   if (!_model[model]) {

      throw new Error(`Model tersedia: ${Object.keys(_model).join(", ")}`);

   }

   const { data: html } = await axios.post(

      `https://api.nekolabs.web.id/px?url=${encodeURIComponent(

         "https://chatgptfree.ai/"

      )}&version=v2`

   );

   const nonce = html.result.content.match(

      /&quot;nonce&quot;\s*:\s*&quot;([^&]+)&quot;/

   );

   if (!nonce) throw new Error("Nonce tidak ditemukan");

   const { data } = await axios.post(

      `https://api.nekolabs.web.id/px?url=${encodeURIComponent(

         "https://chatgptfree.ai/wp-admin/admin-ajax.php"

      )}&version=v2`,

      new URLSearchParams({

         action: "aipkit_frontend_chat_message",

         _ajax_nonce: nonce[1],

         bot_id: _model[model],

         session_id: uuidv4(),

         conversation_uuid: uuidv4(),

         post_id: "6",

         message: question

      }).toString()

   );

   return data.result.content.data.reply;

}

export const run = {

   usage: ["ai", "ask", "openai"],

   use: "text",

   category: "ai",

   cooldown: 5,

   limit: true,

   async: async (m, { client, text, Utils }) => {

      try {

         const query = text?.trim();

         if (!query) return;

         client.sendReact(m.chat, "🤖", m.key);

         const result = await aichat(query, {

            model: "gpt-5-nano"

         });

         // === LANGSUNG JAWAB, TANPA HEADER ANEH, TANPA NANYA BALIK ===

         await client.reply(m.chat, result.trim(), m);

         client.sendReact(m.chat, "✅", m.key);

      } catch (e) {

         console.error("AI ERROR:", e);

         client.sendReact(m.chat, "❌", m.key);

         return client.reply(

            m.chat,

            `❌ AI Error: ${e.message}`,

            m

         );

      }

   },

   error: false,

   limit: true

};