export const run = {
	usage: ["donasi", "donate"],
	use: '', // Tidak memerlukan argumen
	category: 'information',
	cooldown: 3,
	limit: false,
	async: async (m, {
		client,
		Utils
	}) => {
		try {
			// URL Gambar QR Donasi
			const imageUrl = "https://files.catbox.moe/a169b9.png"; 
			
			const caption = `
╭───❏ *Dukungan Donasi IkyBot* ❏
│
│ 💬 _Setiap donasi yang kamu berikan_
│ akan membantu:
│
│ ⚡ Membayar biaya *server & domain*
│ 📶 Menanggung *tagihan WiFi & listrik*
│ 🚀 Mendukung *update fitur bot* ke depan
│
│ 🙏 Terima kasih telah mendukung
│ Tim Pengembang *IkyBot*!
│
│ 📸 Scan QR di atas untuk berdonasi!
╰───────────────────────❏
`;
			
			// Mengganti sock.sendMessage dengan client.sendMessage
			await client.sendMessage(m.chat, {
				image: { url: imageUrl },
				caption: caption.trim(),
			}, {
				quoted: m // Mengutip pesan asli
			});

			// Mengganti m.react dengan client.sendReact
			await client.sendReact(m.chat, "💖", m.key);

		} catch (err) {
			console.error("Donasi Error:", err);
			// Mengganti m.reply dengan client.reply
			return client.reply(m.chat, Utils.texted('bold', "❌ Terjadi kesalahan saat menampilkan menu donasi."), m);
		}
	},
	error: false,
};
