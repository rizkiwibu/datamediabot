import MAL from "../../lib/mal.js";

export const run = {

    usage: ["myanimelist"],

    use: "myanimelist search naruto",

    category: "anime",

    async: async (m, { client, text }) => {

        try {

            const [cmd, ...rest] = text.split(" ");

            const query = rest.join(" ").trim();

            if (!cmd)

                return m.reply(

                    `❌ Pilihan tidak valid!\n\n` +

                    `• myanimelist update\n` +

                    `• myanimelist search <judul>\n` +

                    `• myanimelist detail <url>\n` +

                    `• myanimelist top`

                );

            // ==========================

            // UPDATE (SEASON NOW)

            // ==========================

            if (cmd === "update") {

                const list = await MAL.seasonNow();

                for (let a of list.slice(0, 8)) {

                    await client.sendMessage(

                        m.chat,

                        {

                            image: { url: a.cover },

                            caption:

                                `🌸 *Anime Musim Ini*\n\n` +

                                `🎌 *${a.title}*\n` +

                                `⭐ Score: ${a.score}\n` +

                                `🏢 Studio: ${a.studio}\n` +

                                `🎞 Episodes: ${a.episodes}\n` +

                                `⏱ Duration: ${a.duration}\n\n` +

                                `📜 ${a.synopsis}\n\n` +

                                `🔗 ${a.url}`

                        },

                        { quoted: m }

                    );

                }

                return;

            }

            // ==========================

            // SEARCH (ANIME)

            // ==========================

            if (cmd === "search") {

                if (!query) return m.reply("Masukkan judul anime!");

                const list = await MAL.animeSearch(query);

                if (!list.length) return m.reply("Anime tidak ditemukan!");

                for (let a of list.slice(0, 5)) {

                    await client.sendMessage(

                        m.chat,

                        {

                            image: { url: a.cover },

                            caption:

                                `🎌 *${a.title}*\n\n` +

                                `⭐ Score: ${a.score}\n` +

                                `📚 Type: ${a.type}\n` +

                                `🎞 Episodes: ${a.episodes}\n\n` +

                                `📜 ${a.description}\n\n` +

                                `🔗 ${a.url}`

                        },

                        { quoted: m }

                    );

                }

                return;

            }

            // ==========================

            // DETAIL

            // ==========================

            if (cmd === "detail") {

                if (!query.startsWith("https://myanimelist.net/anime"))

                    return m.reply("Harus URL anime MAL!");

                const a = await MAL.animeDetail(query);

                return client.sendMessage(

                    m.chat,

                    {

                        image: { url: a.cover },

                        caption:

                            `🎌 *${a.title}*\n\n` +

                            `⭐ Score: ${a.score}\n` +

                            `🏅 Rank: ${a.rank}\n` +

                            `🏢 Studio: ${a.studio}\n` +

                            `🎞 Episodes: ${a.episodes}\n` +

                            `📺 Status: ${a.status}\n\n` +

                            `📜 ${a.synopsis}\n\n` +

                            `🔗 ${a.url}`

                    },

                    { quoted: m }

                );

            }

            // ==========================

            // TOP ANIME

            // ==========================

            if (cmd === "top") {

                const list = await MAL.topAnime();

                let text = "🔥 *TOP ANIME MAL*\n\n";

                list.slice(0, 20).forEach(a => {

                    text += `#${a.rank} — *${a.title}* (⭐ ${a.score})\n${a.url}\n\n`;

                });

                return m.reply(text);

            }

        } catch (e) {

            return m.reply("Error: " + e.message);

        }

    },

    error: false,

    limit: false

};