import axios from "axios";

import uploader from "../../lib/uploader.js";

export const run = {

   usage: ['remini'],

   use: 'reply photo',

   category: 'utilities',

   async: async (m, { client, Utils }) => {

      try {

         // Ambil media (harus reply photo)

         const q = m.quoted ? m.quoted : m;

         const mime = (q.msg || q).mimetype || "";

         if (!mime) return m.reply("🚫 Reply photo yang ingin diperjelas.");

         if (!/image\/(jpe?g|png)/.test(mime))

            return m.reply("🚫 Hanya foto JPG/PNG yang bisa diproses.");

         // React ⌛ (Sedang diproses)

         client.sendReact(m.chat, "⌛", m.key);

         // Download buffer

         const media = await q.download();

         const buffer = Buffer.isBuffer(media) ? media : Buffer.from(media);

         // Upload via uploader

         const imageUrl = await uploader.upload(buffer);

         if (!imageUrl) return m.reply("❌ Upload gambar gagal.");

         // Request Remini API Baru

         // Menggunakan parameter 'imageUrl' dan apikey 'freeApikey' sesuai contoh Anda

         const { data: json } = await axios.get(

            `https://anabot.my.id/api/ai/remini?imageUrl=${encodeURIComponent(imageUrl)}&apikey=freeApikey`

         );

         // Cek status keberhasilan berdasarkan struktur respon baru

         if (!json.success || !json.data?.result) {

            return m.reply("❌ Gagal memperjelas gambar. Silakan coba lagi nanti.");

         }

         // Kirim hasil HD dari json.data.result

         await client.sendFile(

            m.chat,

            json.data.result,

            "remini.jpg",

            "✅ *Foto berhasil diperjelas (HD)*",

            m

         );

         // Beri tanda centang selesai

         client.sendReact(m.chat, "✅", m.key);

         // Pesan donasi

         return client.reply(

            m.chat,

            `🙏 *Jangan lupa support ya kak!*\nKetik *donasi* untuk melihat QRIS ❤️`,

            m

         );

      } catch (e) {

         console.error("REMINI ERROR:", e);

         return m.reply("⚠️ Terjadi kesalahan pada sistem.");

      }

   },

   error: false,

   limit: true,

   premium: false

};