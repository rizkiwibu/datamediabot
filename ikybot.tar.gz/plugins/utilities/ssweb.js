import axios from 'axios'

export const run = {
	usage: ["ssweb", "screenshot"],
	use: 'url',
	category: 'tools',
	cooldown: 5,
	limit: true,
	async: async (m, {
		client,
		text, // Menggunakan 'text' sebagai URL input
		isPrefix,
		command,
		Utils
	}) => {
		try {
			const url = text?.trim();

			if (!url) {
				return client.reply(m.chat, Utils.example(isPrefix, command, 'https://example.com'), m);
			}

			// Menggunakan reaksi '📸' sebagai loading
			client.sendReact(m.chat, '📸', m.key);

			// API URL untuk screenshot
			const apiUrl = `https://api.nekolabs.web.id/tools/ssweb?url=${encodeURIComponent(url)}&device=desktop&fullPage=true`;

			// Mengganti fetch dengan axios
			const { data } = await axios.get(apiUrl);

			if (!data.success || !data.result) {
				client.sendReact(m.chat, '❌', m.key);
				throw new Error(data.message || "Screenshot gagal diambil.");
			}

			const imageUrl = data.result;

			const caption = `
📷 *Screenshot (Desktop)*
🌍 *URL:* ${url}
`.trim();

			// Mengganti sock.sendMessage dengan client.sendMessage
			await client.sendMessage(m.chat, {
				image: { url: imageUrl },
				caption,
			}, {
				quoted: m
			});

			client.sendReact(m.chat, '✅', m.key);
			
		} catch (err) {
			console.error("SSWeb Error:", err);
			client.sendReact(m.chat, '❌', m.key);
			const errorMessage = err.message.includes('HTTP') ? `Gagal menghubungi API. ${err.message}` : err.message;
			return client.reply(m.chat, Utils.texted('bold', `❌ Terjadi kesalahan: ${errorMessage}`), m);
		}
	},
	error: false,
};
